"""
Centralized filesystem paths for Creator Studio AI.

All modules should import paths from here rather than building their own
relative paths, so the on-disk layout only needs to be changed in one place
(and stays correct whether running from source or from a PyInstaller .exe).
"""

from __future__ import annotations

import sys
from pathlib import Path


def _get_base_dir() -> Path:
    """Return the directory the application is running from.

    When frozen by PyInstaller, sys.executable points at the .exe and all
    bundled data lives alongside it (or in sys._MEIPASS for one-file mode).
    When running from source, it's the project root (parent of /utils).
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


BASE_DIR: Path = _get_base_dir()

ASSETS_DIR: Path = BASE_DIR / "assets"
ICONS_DIR: Path = ASSETS_DIR / "icons"
THEMES_DIR: Path = ASSETS_DIR / "themes"

DATABASE_DIR: Path = BASE_DIR / "database"
DATABASE_FILE: Path = DATABASE_DIR / "creator_studio.db"

CONFIG_DIR: Path = BASE_DIR / "config"
SETTINGS_FILE: Path = CONFIG_DIR / "settings.json"

LOGS_DIR: Path = BASE_DIR / "logs"
LOG_FILE: Path = LOGS_DIR / "creator_studio.log"

CACHE_DIR: Path = BASE_DIR / "cache"
BACKUPS_DIR: Path = BASE_DIR / "backups"
TEMPLATES_DIR: Path = BASE_DIR / "templates"
PLUGINS_DIR: Path = BASE_DIR / "plugins"
PROJECTS_DIR: Path = BASE_DIR / "projects"


def ensure_runtime_directories() -> None:
    """Create every directory the app writes to, if it doesn't exist yet."""
    for directory in (
        ASSETS_DIR,
        ICONS_DIR,
        THEMES_DIR,
        DATABASE_DIR,
        CONFIG_DIR,
        LOGS_DIR,
        CACHE_DIR,
        BACKUPS_DIR,
        TEMPLATES_DIR,
        PLUGINS_DIR,
        PROJECTS_DIR,
    ):
        directory.mkdir(parents=True, exist_ok=True)
