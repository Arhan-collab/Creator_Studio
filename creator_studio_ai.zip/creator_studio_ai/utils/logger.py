"""
Application-wide logging configuration.

Call configure_logging() exactly once, on startup, from main.py.
Every other module should just do: logger = logging.getLogger(__name__)
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from utils.paths import LOG_FILE, LOGS_DIR

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_configured = False


def configure_logging(level: int = logging.INFO) -> None:
    """Configure the root logger with a rotating file handler and console
    handler. Safe to call multiple times; only configures once.
    """
    global _configured
    if _configured:
        return

    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    file_handler = RotatingFileHandler(
        LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(level)

    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    _configured = True
    logging.getLogger(__name__).info("Logging initialized. Log file: %s", LOG_FILE)
