"""
SQLite database manager for Creator Studio AI.

Responsibilities:
- Open a single, thread-safe connection to the app database.
- Initialize schema on first run.
- Apply forward-only migrations when SCHEMA_VERSION increases.
- Provide simple, safe query/execute helpers used by the rest of the app.
"""

from __future__ import annotations

import logging
import sqlite3
import threading
from contextlib import contextmanager
from typing import Any, Iterator, Sequence

from config.app_config import SCHEMA_VERSION
from utils.paths import DATABASE_FILE

logger = logging.getLogger(__name__)

# Each migration takes the connection at version N-1 and brings it to N.
# Keyed by the target version it produces.
_MIGRATIONS: dict[int, list[str]] = {
    1: [
        """
        CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            project_type TEXT NOT NULL DEFAULT 'General',
            status TEXT NOT NULL DEFAULT 'Active',
            tags TEXT NOT NULL DEFAULT '',
            is_favorite INTEGER NOT NULL DEFAULT 0,
            client TEXT NOT NULL DEFAULT '',
            deadline TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE INDEX IF NOT EXISTS idx_projects_status ON projects (status);
        """,
        """
        CREATE INDEX IF NOT EXISTS idx_projects_updated_at ON projects (updated_at);
        """,
        """
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER REFERENCES projects (id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            is_done INTEGER NOT NULL DEFAULT 0,
            due_date TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks (due_date);
        """,
        """
        CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            details TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
    ],
    2: [
        """
        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER REFERENCES projects (id) ON DELETE SET NULL,
            name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            asset_type TEXT NOT NULL DEFAULT 'Other',
            tags TEXT NOT NULL DEFAULT '',
            is_favorite INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        "CREATE INDEX IF NOT EXISTS idx_assets_type ON assets (asset_type);",
        "CREATE INDEX IF NOT EXISTS idx_assets_project ON assets (project_id);",
        """
        CREATE TABLE IF NOT EXISTS generated_content (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER REFERENCES projects (id) ON DELETE SET NULL,
            content_type TEXT NOT NULL,
            platform TEXT NOT NULL DEFAULT '',
            prompt_topic TEXT NOT NULL DEFAULT '',
            content_text TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        "CREATE INDEX IF NOT EXISTS idx_generated_content_type ON generated_content (content_type);",
        """
        CREATE TABLE IF NOT EXISTS content_ideas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT 'General',
            is_used INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS calendar_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER REFERENCES projects (id) ON DELETE SET NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            event_date TEXT NOT NULL,
            event_type TEXT NOT NULL DEFAULT 'Upload',
            is_reminder_sent INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        "CREATE INDEX IF NOT EXISTS idx_calendar_events_date ON calendar_events (event_date);",
        """
        CREATE TABLE IF NOT EXISTS analytics_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT NOT NULL,
            metric_type TEXT NOT NULL,
            value REAL NOT NULL DEFAULT 0,
            recorded_date TEXT NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        "CREATE INDEX IF NOT EXISTS idx_analytics_platform ON analytics_entries (platform, metric_type);",
        """
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS checklist_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            is_done INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS bookmarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            url TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS snippets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS clipboard_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS brand_kit_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_type TEXT NOT NULL,
            label TEXT NOT NULL,
            value TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """,
        "CREATE INDEX IF NOT EXISTS idx_brand_kit_type ON brand_kit_items (item_type);",
    ],
}


class DatabaseManager:
    """Owns the single SQLite connection and schema lifecycle."""

    def __init__(self, db_path: str | None = None) -> None:
        self._db_path = db_path or str(DATABASE_FILE)
        self._lock = threading.RLock()
        self._connection: sqlite3.Connection | None = None

    def connect(self) -> None:
        with self._lock:
            if self._connection is not None:
                return
            DATABASE_FILE.parent.mkdir(parents=True, exist_ok=True)
            self._connection = sqlite3.connect(
                self._db_path, check_same_thread=False
            )
            self._connection.row_factory = sqlite3.Row
            self._connection.execute("PRAGMA foreign_keys = ON;")
            logger.info("Connected to database at %s", self._db_path)
            self._initialize_schema_version_table()
            self._run_migrations()

    def _initialize_schema_version_table(self) -> None:
        assert self._connection is not None
        with self._connection:
            self._connection.execute(
                """
                CREATE TABLE IF NOT EXISTS schema_version (
                    version INTEGER NOT NULL
                );
                """
            )
            row = self._connection.execute("SELECT version FROM schema_version").fetchone()
            if row is None:
                self._connection.execute(
                    "INSERT INTO schema_version (version) VALUES (0)"
                )

    def _get_current_version(self) -> int:
        assert self._connection is not None
        row = self._connection.execute("SELECT version FROM schema_version").fetchone()
        return int(row["version"]) if row else 0

    def _run_migrations(self) -> None:
        assert self._connection is not None
        current_version = self._get_current_version()
        if current_version >= SCHEMA_VERSION:
            logger.info("Database schema up to date (version %d).", current_version)
            return

        for target_version in range(current_version + 1, SCHEMA_VERSION + 1):
            statements = _MIGRATIONS.get(target_version, [])
            logger.info("Applying migration to schema version %d.", target_version)
            with self._connection:
                for statement in statements:
                    self._connection.execute(statement)
                self._connection.execute(
                    "UPDATE schema_version SET version = ?", (target_version,)
                )
        logger.info("Database migrated to schema version %d.", SCHEMA_VERSION)

    @contextmanager
    def cursor(self) -> Iterator[sqlite3.Cursor]:
        """Context manager yielding a cursor, guarded by the connection lock
        and committing automatically on success."""
        with self._lock:
            assert self._connection is not None, "DatabaseManager.connect() was not called"
            cur = self._connection.cursor()
            try:
                yield cur
                self._connection.commit()
            except Exception:
                self._connection.rollback()
                raise
            finally:
                cur.close()

    def execute(self, query: str, params: Sequence[Any] = ()) -> int:
        """Run an INSERT/UPDATE/DELETE. Returns lastrowid."""
        with self.cursor() as cur:
            cur.execute(query, params)
            return cur.lastrowid

    def query(self, query: str, params: Sequence[Any] = ()) -> list[sqlite3.Row]:
        """Run a SELECT and return all rows."""
        with self.cursor() as cur:
            cur.execute(query, params)
            return cur.fetchall()

    def query_one(self, query: str, params: Sequence[Any] = ()) -> sqlite3.Row | None:
        with self.cursor() as cur:
            cur.execute(query, params)
            return cur.fetchone()

    def close(self) -> None:
        with self._lock:
            if self._connection is not None:
                self._connection.close()
                self._connection = None
                logger.info("Database connection closed.")


# Module-level singleton, connected once from main.py at startup.
db_manager = DatabaseManager()
