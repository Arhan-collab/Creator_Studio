"""
Base class for all pages ("views" in the MVC sense) shown in the main
content area. Provides the lifecycle hooks the app window relies on, so
every page behaves consistently: created once, shown/hidden on navigation,
and given a chance to clean up background work when the app closes.
"""

from __future__ import annotations

import customtkinter as ctk


class BasePage(ctk.CTkFrame):
    """Every page in /pages should subclass this.

    Lifecycle:
        __init__       -> build widgets once, when first navigated to.
        on_show()      -> called every time the page becomes visible.
                          Override to refresh data (e.g. Dashboard stats).
        on_hide()      -> called when navigating away from this page.
        on_app_close() -> called once, right before the app exits.
    """

    #: Unique key matching the entry in config.app_config.NAV_ITEMS.
    page_key: str = ""

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, fg_color="transparent", **kwargs)

    def on_show(self) -> None:
        """Called every time this page is navigated to. Override to refresh."""

    def on_hide(self) -> None:
        """Called when navigating away from this page. Override if needed."""

    def on_app_close(self) -> None:
        """Called once before the application exits. Override to stop any
        background threads/timers owned by this page."""
