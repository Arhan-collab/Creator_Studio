"""
Shared base class for every AI-powered generator page (AI Writer, Script
Writer, Title/Caption/Description/Hashtag Generator, Content Ideas).

Handles the parts that are identical across all of them:
- Running the AI call on a background thread so the UI never freezes
- Showing "No AI provider configured." cleanly when nothing is set up
- Persisting results to generated_content and listing recent history
- Copy-to-clipboard for results

Subclasses only need to build their specific input form and implement
build_prompt().
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime

import customtkinter as ctk

from database.db_manager import db_manager
from modules.base_page import BasePage
from services.ai.ai_provider import AIRequest, get_active_provider

logger = logging.getLogger(__name__)


class GeneratorPageBase(BasePage):
    #: Value stored in generated_content.content_type. Set by subclasses.
    content_type: str = "generic"
    #: Page title shown at the top.
    page_title: str = "Generator"
    #: Short helper text shown under the title.
    page_subtitle: str = ""

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._output_textbox: ctk.CTkTextbox | None = None
        self._generate_button: ctk.CTkButton | None = None
        self._status_label: ctk.CTkLabel | None = None
        self._history_frame: ctk.CTkFrame | None = None
        self._build_page_shell()

    # ---------------------------------------------------------------- Shell

    def _build_page_shell(self) -> None:
        header = ctk.CTkLabel(
            self, text=self.page_title, font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 2))

        if self.page_subtitle:
            ctk.CTkLabel(
                self,
                text=self.page_subtitle,
                font=ctk.CTkFont(size=13),
                text_color=("gray40", "gray65"),
                anchor="w",
            ).pack(fill="x", padx=24, pady=(0, 12))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=24, pady=(0, 16))

        form_card = ctk.CTkFrame(scroll, corner_radius=12)
        form_card.pack(fill="x", pady=(0, 12))
        form_body = ctk.CTkFrame(form_card, fg_color="transparent")
        form_body.pack(fill="x", padx=18, pady=16)
        self.build_form(form_body)

        action_row = ctk.CTkFrame(form_body, fg_color="transparent")
        action_row.pack(fill="x", pady=(12, 0))
        self._generate_button = ctk.CTkButton(
            action_row, text="Generate", command=self._on_generate_clicked, width=140
        )
        self._generate_button.pack(side="left")
        self._status_label = ctk.CTkLabel(action_row, text="", text_color=("gray40", "gray65"))
        self._status_label.pack(side="left", padx=(12, 0))

        output_card = ctk.CTkFrame(scroll, corner_radius=12)
        output_card.pack(fill="both", expand=True, pady=(0, 12))
        ctk.CTkLabel(
            output_card, text="Result", font=ctk.CTkFont(size=15, weight="bold"), anchor="w"
        ).pack(fill="x", padx=18, pady=(14, 6))
        self._output_textbox = ctk.CTkTextbox(output_card, height=220, wrap="word")
        self._output_textbox.pack(fill="both", expand=True, padx=18, pady=(0, 10))

        output_actions = ctk.CTkFrame(output_card, fg_color="transparent")
        output_actions.pack(fill="x", padx=18, pady=(0, 14))
        ctk.CTkButton(output_actions, text="Copy Result", width=130, command=self._copy_result).pack(
            side="left"
        )
        ctk.CTkButton(
            output_actions, text="Save to History", width=140, command=self._save_result, fg_color="gray40"
        ).pack(side="left", padx=(8, 0))

        history_card = ctk.CTkFrame(scroll, corner_radius=12)
        history_card.pack(fill="both", expand=True)
        ctk.CTkLabel(
            history_card, text="Recent History", font=ctk.CTkFont(size=15, weight="bold"), anchor="w"
        ).pack(fill="x", padx=18, pady=(14, 6))
        self._history_frame = ctk.CTkFrame(history_card, fg_color="transparent")
        self._history_frame.pack(fill="both", expand=True, padx=18, pady=(0, 14))

        self.refresh_history()

    # --------------------------------------------------------- Subclass API

    def build_form(self, parent: ctk.CTkFrame) -> None:
        """Override to add topic/platform/tone inputs etc. Called once."""
        raise NotImplementedError

    def build_prompt(self) -> tuple[str, str]:
        """Override to return (system_prompt, user_prompt) from current form
        values. Return ("", "") to abort with a validation message shown via
        self.set_status()."""
        raise NotImplementedError

    def get_platform(self) -> str:
        return ""

    def get_topic(self) -> str:
        return ""

    # ------------------------------------------------------------ Behavior

    def on_show(self) -> None:
        self.refresh_history()

    def set_status(self, message: str) -> None:
        if self._status_label is not None:
            self._status_label.configure(text=message)

    def _on_generate_clicked(self) -> None:
        system_prompt, user_prompt = self.build_prompt()
        if not user_prompt:
            return  # build_prompt already set a validation status message

        provider = get_active_provider()
        if not provider.is_configured():
            self._output_textbox.delete("1.0", "end")
            self._output_textbox.insert("1.0", "No AI provider configured.")
            self.set_status("Configure a provider in Settings \u2192 AI Settings first.")
            return

        self._generate_button.configure(state="disabled", text="Generating...")
        self.set_status("Contacting AI provider...")

        thread = threading.Thread(
            target=self._run_generation,
            args=(provider, system_prompt, user_prompt),
            daemon=True,
        )
        thread.start()

    def _run_generation(self, provider, system_prompt: str, user_prompt: str) -> None:
        request = AIRequest(prompt=user_prompt, system_prompt=system_prompt or None)
        response = provider.generate(request)
        self.after(0, lambda: self._on_generation_complete(response))

    def _on_generation_complete(self, response) -> None:
        self._generate_button.configure(state="normal", text="Generate")
        self._output_textbox.delete("1.0", "end")
        if response.success:
            self._output_textbox.insert("1.0", response.text)
            self.set_status("Done.")
        else:
            self._output_textbox.insert("1.0", response.error or "Generation failed.")
            self.set_status("Generation failed.")

    def _copy_result(self) -> None:
        text = self._output_textbox.get("1.0", "end").strip()
        if not text:
            return
        self.clipboard_clear()
        self.clipboard_append(text)
        self.set_status("Copied to clipboard.")

    def _save_result(self) -> None:
        text = self._output_textbox.get("1.0", "end").strip()
        if not text:
            self.set_status("Nothing to save yet.")
            return
        db_manager.execute(
            """
            INSERT INTO generated_content (content_type, platform, prompt_topic, content_text, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                self.content_type,
                self.get_platform(),
                self.get_topic(),
                text,
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
        self.set_status("Saved to history.")
        self.refresh_history()

    def refresh_history(self) -> None:
        if self._history_frame is None:
            return
        for widget in self._history_frame.winfo_children():
            widget.destroy()

        rows = db_manager.query(
            """
            SELECT id, platform, prompt_topic, content_text, created_at
            FROM generated_content
            WHERE content_type = ?
            ORDER BY id DESC
            LIMIT 10
            """,
            (self.content_type,),
        )
        if not rows:
            ctk.CTkLabel(
                self._history_frame, text="No history yet.", text_color=("gray40", "gray65")
            ).pack(anchor="w")
            return

        for row in rows:
            item_frame = ctk.CTkFrame(self._history_frame, fg_color=("gray92", "gray17"), corner_radius=8)
            item_frame.pack(fill="x", pady=3)

            label_text = row["prompt_topic"] or "(no topic)"
            if row["platform"]:
                label_text += f"  \u2022  {row['platform']}"
            label_text += f"  \u2022  {row['created_at']}"

            ctk.CTkLabel(item_frame, text=label_text, anchor="w", font=ctk.CTkFont(size=12)).pack(
                fill="x", padx=10, pady=(6, 2)
            )
            preview = row["content_text"][:160].replace("\n", " ")
            ctk.CTkLabel(
                item_frame,
                text=preview + ("..." if len(row["content_text"]) > 160 else ""),
                anchor="w",
                text_color=("gray30", "gray70"),
                font=ctk.CTkFont(size=11),
                wraplength=760,
                justify="left",
            ).pack(fill="x", padx=10, pady=(0, 4))

            button_row = ctk.CTkFrame(item_frame, fg_color="transparent")
            button_row.pack(fill="x", padx=10, pady=(0, 6))
            ctk.CTkButton(
                button_row,
                text="Load",
                width=70,
                height=24,
                command=lambda text=row["content_text"]: self._load_history_item(text),
            ).pack(side="left", padx=(0, 6))
            ctk.CTkButton(
                button_row,
                text="Delete",
                width=70,
                height=24,
                fg_color="darkred",
                command=lambda item_id=row["id"]: self._delete_history_item(item_id),
            ).pack(side="left")

    def _load_history_item(self, text: str) -> None:
        self._output_textbox.delete("1.0", "end")
        self._output_textbox.insert("1.0", text)

    def _delete_history_item(self, item_id: int) -> None:
        db_manager.execute("DELETE FROM generated_content WHERE id = ?", (item_id,))
        self.refresh_history()
