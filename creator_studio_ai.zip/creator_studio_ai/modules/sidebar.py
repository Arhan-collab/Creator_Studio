"""
Sidebar navigation: a scrollable list of nav buttons matching NAV_ITEMS.
Highlights the active page and calls back into the app window's router
when a different item is selected.
"""

from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from config.app_config import APP_NAME, APP_TAGLINE, NAV_ITEMS


class Sidebar(ctk.CTkFrame):
    def __init__(
        self,
        master: ctk.CTkBaseClass,
        on_navigate: Callable[[str], None],
        **kwargs,
    ) -> None:
        super().__init__(master, width=240, corner_radius=0, **kwargs)
        self.grid_propagate(False)
        self._on_navigate = on_navigate
        self._buttons: dict[str, ctk.CTkButton] = {}
        self._active_key: str | None = None

        self._build_header()
        self._build_nav_buttons()

    def _build_header(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=16, pady=(20, 12))

        title_label = ctk.CTkLabel(
            header,
            text=APP_NAME,
            font=ctk.CTkFont(size=18, weight="bold"),
            anchor="w",
        )
        title_label.pack(fill="x")

        tagline_label = ctk.CTkLabel(
            header,
            text=APP_TAGLINE,
            font=ctk.CTkFont(size=11),
            text_color=("gray40", "gray60"),
            anchor="w",
            wraplength=200,
            justify="left",
        )
        tagline_label.pack(fill="x", pady=(2, 0))

        separator = ctk.CTkFrame(self, height=1, fg_color=("gray80", "gray25"))
        separator.pack(fill="x", padx=16, pady=(4, 8))

    def _build_nav_buttons(self) -> None:
        scroll_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        for key, label, glyph in NAV_ITEMS:
            button = ctk.CTkButton(
                scroll_frame,
                text=f"{glyph}   {label}",
                anchor="w",
                height=38,
                corner_radius=8,
                fg_color="transparent",
                text_color=("gray10", "gray90"),
                hover_color=("gray85", "gray25"),
                font=ctk.CTkFont(size=13),
                command=lambda k=key: self._handle_click(k),
            )
            button.pack(fill="x", pady=2, padx=2)
            self._buttons[key] = button

    def _handle_click(self, key: str) -> None:
        self.set_active(key)
        self._on_navigate(key)

    def set_active(self, key: str) -> None:
        if self._active_key is not None and self._active_key in self._buttons:
            self._buttons[self._active_key].configure(
                fg_color="transparent", text_color=("gray10", "gray90")
            )
        if key in self._buttons:
            self._buttons[key].configure(
                fg_color=("gray75", "gray30"), text_color=("black", "white")
            )
            self._active_key = key
