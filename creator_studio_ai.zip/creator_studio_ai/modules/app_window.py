"""
Main application window.

Owns the top-level CTk window, the sidebar, and the content area. Routes
navigation clicks to the right page, lazily instantiating each page the
first time it's visited and reusing it afterward.
"""

from __future__ import annotations

import logging

import customtkinter as ctk

from config.app_config import (
    APP_NAME,
    DEFAULT_WINDOW_HEIGHT,
    DEFAULT_WINDOW_WIDTH,
    IMPLEMENTED_PAGES,
    MIN_WINDOW_HEIGHT,
    MIN_WINDOW_WIDTH,
    NAV_ITEMS,
)
from modules.base_page import BasePage
from modules.sidebar import Sidebar
from pages.about_page import AboutPage
from pages.ai_writer_page import AIWriterPage
from pages.analytics_page import AnalyticsPage
from pages.asset_manager_page import AssetManagerPage
from pages.brand_kit_page import BrandKitPage
from pages.caption_generator_page import CaptionGeneratorPage
from pages.coming_soon_page import ComingSoonPage
from pages.content_calendar_page import ContentCalendarPage
from pages.content_ideas_page import ContentIdeasPage
from pages.dashboard_page import DashboardPage
from pages.description_generator_page import DescriptionGeneratorPage
from pages.hashtag_generator_page import HashtagGeneratorPage
from pages.productivity_page import ProductivityPage
from pages.projects_page import ProjectsPage
from pages.script_writer_page import ScriptWriterPage
from pages.settings_page import SettingsPage
from pages.thumbnail_studio_page import ThumbnailStudioPage
from pages.title_generator_page import TitleGeneratorPage
from services.autosave_service import autosave_service
from services.file_watcher_service import file_watcher_service
from services.notification_center import notification_center
from services.plugin_manager import plugin_manager
from services.search_indexer import search_everything

logger = logging.getLogger(__name__)

_NAV_LABELS: dict[str, str] = {key: label for key, label, _ in NAV_ITEMS}

_PAGE_CLASSES: dict[str, type[BasePage]] = {
    "dashboard": DashboardPage,
    "projects": ProjectsPage,
    "ai_writer": AIWriterPage,
    "script_writer": ScriptWriterPage,
    "thumbnail_studio": ThumbnailStudioPage,
    "title_generator": TitleGeneratorPage,
    "caption_generator": CaptionGeneratorPage,
    "description_generator": DescriptionGeneratorPage,
    "hashtag_generator": HashtagGeneratorPage,
    "content_ideas": ContentIdeasPage,
    "content_calendar": ContentCalendarPage,
    "asset_manager": AssetManagerPage,
    "brand_kit": BrandKitPage,
    "analytics": AnalyticsPage,
    "productivity": ProductivityPage,
    "settings": SettingsPage,
    "about": AboutPage,
}


class AppWindow(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()

        self.title(APP_NAME)
        self.geometry(f"{DEFAULT_WINDOW_WIDTH}x{DEFAULT_WINDOW_HEIGHT}")
        self.minsize(MIN_WINDOW_WIDTH, MIN_WINDOW_HEIGHT)

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._pages: dict[str, BasePage] = {}
        self._active_page_key: str | None = None

        self._sidebar = Sidebar(self, on_navigate=self._navigate_to)
        self._sidebar.grid(row=0, column=0, rowspan=2, sticky="nsw")

        self._build_top_bar()

        self._content_container = ctk.CTkFrame(self, fg_color="transparent")
        self._content_container.grid(row=1, column=1, sticky="nsew")
        self._content_container.grid_columnconfigure(0, weight=1)
        self._content_container.grid_rowconfigure(0, weight=1)

        self._bind_shortcuts()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._navigate_to("dashboard")
        self._sidebar.set_active("dashboard")

        autosave_service.start()
        file_watcher_service.start()
        notification_center.bind_root(self)
        plugin_manager.load_all(self)
        if plugin_manager.loaded_plugin_names:
            notification_center.notify(
                "Plugins loaded", ", ".join(plugin_manager.loaded_plugin_names)
            )

    def _build_top_bar(self) -> None:
        top_bar = ctk.CTkFrame(self, fg_color="transparent", height=48)
        top_bar.grid(row=0, column=1, sticky="ew", padx=16, pady=(12, 0))

        self._search_entry = ctk.CTkEntry(top_bar, placeholder_text="Search projects, assets, notes, ideas...")
        self._search_entry.pack(side="left", fill="x", expand=True)
        self._search_entry.bind("<Return>", lambda _e: self._run_global_search())

        ctk.CTkButton(top_bar, text="Search", width=90, command=self._run_global_search).pack(
            side="left", padx=(8, 0)
        )

    def _run_global_search(self) -> None:
        term = self._search_entry.get().strip()
        if not term:
            return
        results = search_everything(term)

        popup = ctk.CTkToplevel(self)
        popup.title(f"Search results for \u201c{term}\u201d")
        popup.geometry("480x420")
        popup.grab_set()

        scroll = ctk.CTkScrollableFrame(popup, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=16, pady=16)

        if not results:
            ctk.CTkLabel(scroll, text="No matches found.", text_color=("gray40", "gray65")).pack(anchor="w")
            return

        for result in results:
            row = ctk.CTkFrame(scroll, fg_color=("gray92", "gray17"), corner_radius=8)
            row.pack(fill="x", pady=3)
            ctk.CTkLabel(
                row, text=f"[{result.category}] {result.title}", font=ctk.CTkFont(weight="bold"), anchor="w"
            ).pack(fill="x", padx=10, pady=(8, 0))
            ctk.CTkLabel(
                row, text=result.subtitle, anchor="w", text_color=("gray30", "gray70"), font=ctk.CTkFont(size=11)
            ).pack(fill="x", padx=10, pady=(0, 6))

            def go_to(page_key=result.page_key, dlg=popup) -> None:
                dlg.destroy()
                self._navigate_to(page_key)

            ctk.CTkButton(row, text="Open", width=70, height=24, command=go_to).pack(anchor="e", padx=10, pady=(0, 8))

    # --------------------------------------------------------------- Router

    def _navigate_to(self, key: str) -> None:
        if self._active_page_key is not None and self._active_page_key in self._pages:
            self._pages[self._active_page_key].on_hide()
            self._pages[self._active_page_key].grid_forget()

        page = self._get_or_create_page(key)
        page.grid(row=0, column=0, sticky="nsew")
        page.on_show()

        self._active_page_key = key
        self._sidebar.set_active(key)

    def _get_or_create_page(self, key: str) -> BasePage:
        if key in self._pages:
            return self._pages[key]

        if key in IMPLEMENTED_PAGES and key in _PAGE_CLASSES:
            page = _PAGE_CLASSES[key](self._content_container)
        else:
            page = ComingSoonPage(self._content_container, section_label=_NAV_LABELS.get(key, key))

        self._pages[key] = page
        return page

    # ------------------------------------------------------------ Shortcuts

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-comma>", lambda _event: self._navigate_to("settings"))
        self.bind("<Control-d>", lambda _event: self._navigate_to("dashboard"))
        self.bind("<Control-q>", lambda _event: self._on_close())

    # ---------------------------------------------------------------- Close

    def _on_close(self) -> None:
        logger.info("Application closing. Running page cleanup hooks.")
        for page in self._pages.values():
            try:
                page.on_app_close()
            except Exception:
                logger.exception("Error while closing page %s", page.page_key)
        autosave_service.stop()
        file_watcher_service.stop()
        self.destroy()
