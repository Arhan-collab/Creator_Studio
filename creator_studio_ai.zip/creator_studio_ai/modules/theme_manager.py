"""
Theme manager: applies appearance mode (dark/light/system) and accent color
consistently across the app, and persists the choice via SettingsManager.
"""

from __future__ import annotations

import logging

import customtkinter as ctk

from config.settings_manager import settings_manager

logger = logging.getLogger(__name__)

_VALID_MODES = {"Dark", "Light", "System"}
_VALID_ACCENTS = {"blue", "green", "dark-blue"}


class ThemeManager:
    """Thin wrapper around customtkinter's global appearance settings."""

    def __init__(self) -> None:
        self._mode = settings_manager.get("appearance", "theme", "Dark")
        self._accent = settings_manager.get("appearance", "accent_color", "blue")

    def apply_startup_theme(self) -> None:
        self.set_mode(self._mode, persist=False)
        self.set_accent(self._accent, persist=False)

    def set_mode(self, mode: str, persist: bool = True) -> None:
        if mode not in _VALID_MODES:
            logger.warning("Ignoring invalid theme mode: %s", mode)
            return
        self._mode = mode
        ctk.set_appearance_mode(mode)
        logger.info("Appearance mode set to %s", mode)
        if persist:
            settings_manager.set("appearance", "theme", mode)

    def set_accent(self, accent: str, persist: bool = True) -> None:
        if accent not in _VALID_ACCENTS:
            logger.warning("Ignoring invalid accent color: %s", accent)
            return
        self._accent = accent
        ctk.set_default_color_theme(accent)
        logger.info("Accent color theme set to %s", accent)
        if persist:
            settings_manager.set("appearance", "accent_color", accent)

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def accent(self) -> str:
        return self._accent


theme_manager = ThemeManager()
