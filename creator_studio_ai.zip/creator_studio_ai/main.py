"""
Creator Studio AI - entry point.

Everything a Creator Needs in One Desktop App.

This wires up, in order:
  1. Runtime directories (assets, database, logs, cache, backups, ...)
  2. Logging
  3. Database connection + schema migrations
  4. Theme
  5. The main window
"""

from __future__ import annotations

import logging
import sys

import customtkinter as ctk

from utils.paths import ensure_runtime_directories

ensure_runtime_directories()

from utils.logger import configure_logging  # noqa: E402  (must run after ensure dirs)

configure_logging()
logger = logging.getLogger(__name__)


def main() -> int:
    logger.info("Starting Creator Studio AI...")

    try:
        from database.db_manager import db_manager

        db_manager.connect()
    except Exception:
        logger.exception("Fatal error initializing the database.")
        return 1

    try:
        ctk.set_widget_scaling(1.0)

        from modules.theme_manager import theme_manager

        theme_manager.apply_startup_theme()

        from modules.app_window import AppWindow

        app = AppWindow()
        app.mainloop()
    except Exception:
        logger.exception("Fatal error in application main loop.")
        return 1
    finally:
        db_manager.close()
        logger.info("Creator Studio AI has shut down.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
