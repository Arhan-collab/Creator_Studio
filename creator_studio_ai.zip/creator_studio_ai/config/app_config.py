"""
Static application configuration constants.

Anything the user can change at runtime belongs in settings_manager.py
(persisted to config/settings.json) instead of here.
"""

from __future__ import annotations

APP_NAME = "Creator Studio AI"
APP_TAGLINE = "Everything a Creator Needs in One Desktop App"
APP_VERSION = "0.1.0-phase1"
ORGANIZATION_NAME = "Creator Studio AI"

MIN_WINDOW_WIDTH = 1100
MIN_WINDOW_HEIGHT = 680
DEFAULT_WINDOW_WIDTH = 1280
DEFAULT_WINDOW_HEIGHT = 800

SCHEMA_VERSION = 2

# Sidebar navigation. Each entry: (unique_key, display_label, icon_glyph).
# icon_glyph is a plain unicode glyph fallback until custom icon assets are
# added in a later phase (keeps this phase dependency-free for icons).
NAV_ITEMS: list[tuple[str, str, str]] = [
    ("dashboard", "Dashboard", "🏠"),
    ("projects", "Projects", "📁"),
    ("ai_writer", "AI Writer", "✍️"),
    ("script_writer", "Script Writer", "🎬"),
    ("thumbnail_studio", "Thumbnail Studio", "🖼️"),
    ("title_generator", "Title Generator", "🔤"),
    ("caption_generator", "Caption Generator", "💬"),
    ("description_generator", "Description Generator", "📝"),
    ("hashtag_generator", "Hashtag Generator", "#️⃣"),
    ("content_ideas", "Content Ideas", "💡"),
    ("content_calendar", "Content Calendar", "📅"),
    ("asset_manager", "Asset Manager", "🗂️"),
    ("brand_kit", "Brand Kit", "🎨"),
    ("analytics", "Analytics", "📊"),
    ("productivity", "Productivity", "✅"),
    ("settings", "Settings", "⚙️"),
    ("about", "About", "ℹ️"),
]

# Pages that are fully implemented in the current phase. Everything else in
# NAV_ITEMS routes to the ComingSoonPage until its phase is built.
IMPLEMENTED_PAGES: set[str] = {
    "dashboard",
    "projects",
    "ai_writer",
    "script_writer",
    "thumbnail_studio",
    "title_generator",
    "caption_generator",
    "description_generator",
    "hashtag_generator",
    "content_ideas",
    "content_calendar",
    "asset_manager",
    "brand_kit",
    "analytics",
    "productivity",
    "settings",
    "about",
}

AI_PROVIDER_CHOICES: list[str] = [
    "None",
    "OpenRouter",
    "OpenAI",
    "Anthropic",
    "Google Gemini",
    "Ollama",
    "Custom",
]

THEME_CHOICES: list[str] = ["Dark", "Light", "System"]

SOCIAL_PLATFORMS: list[str] = [
    "YouTube",
    "Instagram",
    "TikTok",
    "Facebook",
    "LinkedIn",
    "X",
]

CAPTION_TONES: list[str] = [
    "Short",
    "Medium",
    "Long",
    "Professional",
    "Funny",
    "Educational",
    "Motivational",
]

AI_WRITER_CONTENT_TYPES: list[str] = [
    "YouTube Script",
    "Short Video Script",
    "Tutorial",
    "Educational Content",
    "Gaming Content",
    "Technology Review",
    "Product Review",
    "Storytelling",
    "Marketing Copy",
    "Blog Article",
    "Social Media Post",
]

ANALYTICS_METRICS: list[str] = [
    "Views",
    "Likes",
    "Comments",
    "Subscribers",
    "Followers",
    "Revenue",
    "Growth",
    "Engagement",
]

ASSET_TYPES: list[str] = ["Video", "Image", "Audio", "Font", "Template", "Logo", "Other"]
