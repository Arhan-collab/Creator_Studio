"""
Persistent, thread-safe user settings storage.

Settings are stored as JSON at config/settings.json. This module owns the
single source of truth for all user-adjustable state: appearance, autosave,
backups, and the AI provider configuration (never any hardcoded API keys).
"""

from __future__ import annotations

import json
import logging
import threading
from copy import deepcopy
from typing import Any

from utils.paths import SETTINGS_FILE

logger = logging.getLogger(__name__)

DEFAULT_SETTINGS: dict[str, Any] = {
    "appearance": {
        "theme": "Dark",  # "Dark" | "Light" | "System"
        "accent_color": "blue",
    },
    "general": {
        "language": "English",
        "start_on_dashboard": True,
    },
    "autosave": {
        "enabled": True,
        "interval_seconds": 60,
        "last_autosave_at": None,
    },
    "performance": {
        "max_cache_mb": 512,
    },
    "backups": {
        "auto_backup_enabled": False,
        "keep_last_n_backups": 5,
        "last_backup_at": None,
    },
    "ai": {
        "provider": "None",
        "base_url": "",
        "api_key": "",
        "model": "",
        "timeout_seconds": 60,
        "temperature": 0.7,
    },
}


def _deep_merge_defaults(defaults: dict[str, Any], loaded: dict[str, Any]) -> dict[str, Any]:
    """Merge loaded settings on top of defaults so new keys introduced in
    later versions of the app are filled in automatically, without losing
    anything the user has already configured.
    """
    merged = deepcopy(defaults)
    for key, value in loaded.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge_defaults(merged[key], value)
        else:
            merged[key] = value
    return merged


class SettingsManager:
    """Loads, caches, and persists application settings."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._settings: dict[str, Any] = deepcopy(DEFAULT_SETTINGS)
        self.load()

    def load(self) -> None:
        with self._lock:
            if SETTINGS_FILE.exists():
                try:
                    with open(SETTINGS_FILE, "r", encoding="utf-8") as fh:
                        loaded = json.load(fh)
                    self._settings = _deep_merge_defaults(DEFAULT_SETTINGS, loaded)
                    logger.info("Settings loaded from %s", SETTINGS_FILE)
                except (json.JSONDecodeError, OSError) as exc:
                    logger.error("Failed to load settings (%s). Using defaults.", exc)
                    self._settings = deepcopy(DEFAULT_SETTINGS)
            else:
                self._settings = deepcopy(DEFAULT_SETTINGS)
                self._save_locked()
                logger.info("No settings file found. Created defaults at %s", SETTINGS_FILE)

    def save(self) -> None:
        with self._lock:
            self._save_locked()

    def _save_locked(self) -> None:
        SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as fh:
                json.dump(self._settings, fh, indent=2)
        except OSError as exc:
            logger.error("Failed to save settings: %s", exc)

    def get(self, section: str, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._settings.get(section, {}).get(key, default)

    def get_section(self, section: str) -> dict[str, Any]:
        with self._lock:
            return deepcopy(self._settings.get(section, {}))

    def set(self, section: str, key: str, value: Any, persist: bool = True) -> None:
        with self._lock:
            self._settings.setdefault(section, {})[key] = value
            if persist:
                self._save_locked()

    def update_section(self, section: str, values: dict[str, Any], persist: bool = True) -> None:
        with self._lock:
            self._settings.setdefault(section, {}).update(values)
            if persist:
                self._save_locked()

    def export_to_file(self, destination_path: str) -> None:
        with self._lock:
            with open(destination_path, "w", encoding="utf-8") as fh:
                json.dump(self._settings, fh, indent=2)
        logger.info("Settings exported to %s", destination_path)

    def all(self) -> dict[str, Any]:
        with self._lock:
            return deepcopy(self._settings)


# Module-level singleton, created once and shared across the app.
settings_manager = SettingsManager()
