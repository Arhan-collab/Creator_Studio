"""
Backup manager. Creates a timestamped copy of the SQLite database file in
/backups, and prunes old backups beyond the configured retention count.
"""

from __future__ import annotations

import logging
import shutil
from datetime import datetime
from pathlib import Path

from config.settings_manager import settings_manager
from utils.paths import BACKUPS_DIR, DATABASE_FILE

logger = logging.getLogger(__name__)


class BackupService:
    def create_backup(self) -> Path:
        BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destination = BACKUPS_DIR / f"creator_studio_{timestamp}.db"

        if not DATABASE_FILE.exists():
            raise FileNotFoundError(f"No database file found at {DATABASE_FILE}")

        shutil.copy2(DATABASE_FILE, destination)
        logger.info("Backup created at %s", destination)

        settings_manager.set(
            "backups", "last_backup_at", datetime.now().isoformat(timespec="seconds")
        )
        self._prune_old_backups()
        return destination

    def _prune_old_backups(self) -> None:
        keep_last_n = settings_manager.get("backups", "keep_last_n_backups", 5)
        backups = sorted(
            BACKUPS_DIR.glob("creator_studio_*.db"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for old_backup in backups[keep_last_n:]:
            try:
                old_backup.unlink()
                logger.info("Pruned old backup: %s", old_backup)
            except OSError as exc:
                logger.error("Failed to prune backup %s: %s", old_backup, exc)

    def list_backups(self) -> list[Path]:
        BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
        return sorted(
            BACKUPS_DIR.glob("creator_studio_*.db"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )


backup_service = BackupService()
