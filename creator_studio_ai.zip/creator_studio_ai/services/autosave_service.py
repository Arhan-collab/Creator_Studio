"""
Background autosave service.

Runs on its own daemon thread and, at the configured interval, invokes every
registered autosave callback (pages/services can register their own "save my
current state" function) and records the timestamp in settings. This is a
real, working background service - not a placeholder for one.
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime
from typing import Callable

from config.settings_manager import settings_manager

logger = logging.getLogger(__name__)


class AutosaveService:
    def __init__(self) -> None:
        self._callbacks: list[Callable[[], None]] = []
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def register_callback(self, callback: Callable[[], None]) -> None:
        """Register a function to run on every autosave tick."""
        self._callbacks.append(callback)

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run_loop, name="AutosaveThread", daemon=True)
        self._thread.start()
        logger.info("Autosave service started.")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2)
        logger.info("Autosave service stopped.")

    def _run_loop(self) -> None:
        while not self._stop_event.is_set():
            autosave_settings = settings_manager.get_section("autosave")
            enabled = autosave_settings.get("enabled", True)
            interval = max(int(autosave_settings.get("interval_seconds", 60)), 5)

            if self._stop_event.wait(timeout=interval):
                break

            if not enabled:
                continue

            self._run_tick()

    def _run_tick(self) -> None:
        for callback in list(self._callbacks):
            try:
                callback()
            except Exception:
                logger.exception("Autosave callback raised an exception.")
        settings_manager.set(
            "autosave", "last_autosave_at", datetime.now().isoformat(timespec="seconds")
        )
        logger.debug("Autosave tick completed.")


autosave_service = AutosaveService()
