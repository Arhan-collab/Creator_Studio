"""
Cache Manager.

A simple, real, TTL-based disk cache under /cache. Stores a JSON envelope
(value + expiry timestamp) per key so repeated expensive lookups (e.g. an
AI suggestion for the same inputs) can be skipped within their TTL window,
and provides the size/clear operations Settings -> Performance exposes.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Any

from utils.paths import CACHE_DIR

logger = logging.getLogger(__name__)


class CacheManager:
    def __init__(self) -> None:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)

    def _path_for_key(self, key: str) -> Path:
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return CACHE_DIR / f"{digest}.json"

    def set(self, key: str, value: Any, ttl_seconds: int = 3600) -> None:
        envelope = {"expires_at": time.time() + ttl_seconds, "value": value}
        try:
            with open(self._path_for_key(key), "w", encoding="utf-8") as fh:
                json.dump(envelope, fh)
        except OSError as exc:
            logger.error("Cache write failed for key %s: %s", key, exc)

    def get(self, key: str) -> Any | None:
        path = self._path_for_key(key)
        if not path.exists():
            return None
        try:
            with open(path, "r", encoding="utf-8") as fh:
                envelope = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return None
        if time.time() > envelope.get("expires_at", 0):
            path.unlink(missing_ok=True)
            return None
        return envelope.get("value")

    def clear_expired(self) -> int:
        removed = 0
        for path in CACHE_DIR.glob("*.json"):
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    envelope = json.load(fh)
                if time.time() > envelope.get("expires_at", 0):
                    path.unlink(missing_ok=True)
                    removed += 1
            except (OSError, json.JSONDecodeError):
                path.unlink(missing_ok=True)
                removed += 1
        return removed

    def clear_all(self) -> int:
        removed = 0
        for path in CACHE_DIR.glob("*.json"):
            path.unlink(missing_ok=True)
            removed += 1
        return removed

    def get_size_bytes(self) -> int:
        return sum(p.stat().st_size for p in CACHE_DIR.glob("*.json") if p.is_file())


cache_manager = CacheManager()
