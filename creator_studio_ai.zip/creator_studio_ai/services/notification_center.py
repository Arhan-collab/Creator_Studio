"""
Notification Center.

Lightweight in-app toast notifications shown in the bottom-right corner of
the main window. Any service (autosave, backups, file watcher, AI jobs) can
call notify() from a background thread; it safely marshals the popup back
onto the Tk main thread.
"""

from __future__ import annotations

import logging

import customtkinter as ctk

logger = logging.getLogger(__name__)

_TOAST_LIFETIME_MS = 4000
_TOAST_WIDTH = 300


class NotificationCenter:
    def __init__(self) -> None:
        self._root: ctk.CTk | None = None
        self._active_toasts: list[ctk.CTkToplevel] = []

    def bind_root(self, root: ctk.CTk) -> None:
        self._root = root

    def notify(self, title: str, message: str) -> None:
        if self._root is None:
            logger.info("Notification (no UI root yet): %s - %s", title, message)
            return
        self._root.after(0, lambda: self._show_toast(title, message))

    def _show_toast(self, title: str, message: str) -> None:
        assert self._root is not None
        toast = ctk.CTkToplevel(self._root)
        toast.overrideredirect(True)
        toast.attributes("-topmost", True)

        frame = ctk.CTkFrame(toast, corner_radius=10, border_width=1)
        frame.pack(fill="both", expand=True)
        ctk.CTkLabel(frame, text=title, font=ctk.CTkFont(size=13, weight="bold"), anchor="w").pack(
            fill="x", padx=14, pady=(10, 2)
        )
        ctk.CTkLabel(
            frame, text=message, anchor="w", wraplength=_TOAST_WIDTH - 28, justify="left", font=ctk.CTkFont(size=11)
        ).pack(fill="x", padx=14, pady=(0, 10))

        self._root.update_idletasks()
        root_x = self._root.winfo_x()
        root_y = self._root.winfo_y()
        root_w = self._root.winfo_width()
        root_h = self._root.winfo_height()

        stacked_offset = len(self._active_toasts) * 90
        x = root_x + root_w - _TOAST_WIDTH - 24
        y = root_y + root_h - 100 - stacked_offset
        toast.geometry(f"{_TOAST_WIDTH}x80+{x}+{y}")

        self._active_toasts.append(toast)

        def close() -> None:
            if toast in self._active_toasts:
                self._active_toasts.remove(toast)
            try:
                toast.destroy()
            except Exception:
                pass

        toast.after(_TOAST_LIFETIME_MS, close)
        toast.bind("<Button-1>", lambda _e: close())


notification_center = NotificationCenter()
