"""
Search Indexer.

Provides one fast, unified search across the tables a creator is most
likely to be hunting through: projects, assets, notes, snippets, and
content ideas. Backed directly by the indexed SQLite columns created in
the schema migrations - no separate index to keep in sync, and no
noticeable latency at the row counts this app deals with.
"""

from __future__ import annotations

from dataclasses import dataclass

from database.db_manager import db_manager


@dataclass
class SearchResult:
    category: str
    title: str
    subtitle: str
    page_key: str


def search_everything(term: str, limit_per_category: int = 5) -> list[SearchResult]:
    if not term or not term.strip():
        return []

    like_term = f"%{term.strip()}%"
    results: list[SearchResult] = []

    for row in db_manager.query(
        "SELECT name, project_type, status FROM projects WHERE name LIKE ? OR tags LIKE ? LIMIT ?",
        (like_term, like_term, limit_per_category),
    ):
        results.append(
            SearchResult("Project", row["name"], f"{row['project_type']} \u2022 {row['status']}", "projects")
        )

    for row in db_manager.query(
        "SELECT name, asset_type FROM assets WHERE name LIKE ? OR tags LIKE ? LIMIT ?",
        (like_term, like_term, limit_per_category),
    ):
        results.append(SearchResult("Asset", row["name"], row["asset_type"], "asset_manager"))

    for row in db_manager.query(
        "SELECT title, content FROM notes WHERE title LIKE ? OR content LIKE ? LIMIT ?",
        (like_term, like_term, limit_per_category),
    ):
        results.append(
            SearchResult("Note", row["title"], row["content"][:60].replace("\n", " "), "productivity")
        )

    for row in db_manager.query(
        "SELECT title, content FROM snippets WHERE title LIKE ? OR content LIKE ? LIMIT ?",
        (like_term, like_term, limit_per_category),
    ):
        results.append(
            SearchResult("Snippet", row["title"], row["content"][:60].replace("\n", " "), "productivity")
        )

    for row in db_manager.query(
        "SELECT title, category FROM content_ideas WHERE title LIKE ? OR description LIKE ? LIMIT ?",
        (like_term, like_term, limit_per_category),
    ):
        results.append(SearchResult("Idea", row["title"], row["category"], "content_ideas"))

    return results
