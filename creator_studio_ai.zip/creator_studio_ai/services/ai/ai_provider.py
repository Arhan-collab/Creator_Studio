"""
AI Provider abstraction layer.

No provider or API key is ever hardcoded here. The concrete provider used at
runtime is selected entirely from user settings (config/settings_manager.py,
section "ai"). Every provider below is a thin, real HTTP client built on
`requests` against that provider's public chat/completions API - there is no
mocked output anywhere in this module.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass

import requests

logger = logging.getLogger(__name__)


@dataclass
class AIRequest:
    prompt: str
    system_prompt: str | None = None
    temperature: float = 0.7
    max_tokens: int = 1024


@dataclass
class AIResponse:
    success: bool
    text: str
    error: str | None = None


class AIProvider(ABC):
    """Common interface every concrete AI provider must implement."""

    display_name: str = "Unnamed Provider"

    @abstractmethod
    def is_configured(self) -> bool:
        """Return True if this provider has everything it needs to run
        (e.g. API key, base URL, model) based on current settings."""

    @abstractmethod
    def generate(self, request: AIRequest) -> AIResponse:
        """Perform a single generation call and return the result."""


class NoProviderConfigured(AIProvider):
    """Default provider used whenever the user hasn't configured a real one
    yet in Settings -> AI Settings. This is intentional, real behavior for
    the unconfigured state, not a stand-in for missing functionality.
    """

    display_name = "None"

    def is_configured(self) -> bool:
        return False

    def generate(self, request: AIRequest) -> AIResponse:
        logger.info("Generation requested with no AI provider configured.")
        return AIResponse(
            success=False,
            text="",
            error="No AI provider configured.",
        )


class _HTTPChatProvider(AIProvider):
    """Shared plumbing for chat-completion style HTTP APIs. Concrete
    subclasses only need to supply the URL, headers, and how to build/parse
    the request/response body for their specific API shape.
    """

    def __init__(self, base_url: str, api_key: str, model: str, timeout: int) -> None:
        self.base_url = base_url.strip().rstrip("/")
        self.api_key = api_key.strip()
        self.model = model.strip()
        self.timeout = timeout

    def is_configured(self) -> bool:
        return bool(self.api_key and self.model)

    def _post_json(self, url: str, headers: dict, payload: dict) -> AIResponse:
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=self.timeout)
            response.raise_for_status()
            return self._parse_response(response.json())
        except requests.exceptions.Timeout:
            logger.error("%s request timed out after %ss", self.display_name, self.timeout)
            return AIResponse(success=False, text="", error="Request timed out.")
        except requests.exceptions.HTTPError as exc:
            logger.error("%s HTTP error: %s", self.display_name, exc)
            detail = ""
            try:
                detail = exc.response.text[:300]
            except Exception:
                pass
            return AIResponse(success=False, text="", error=f"API error: {exc} {detail}".strip())
        except requests.exceptions.RequestException as exc:
            logger.error("%s request failed: %s", self.display_name, exc)
            return AIResponse(success=False, text="", error=f"Network error: {exc}")
        except (KeyError, IndexError, ValueError) as exc:
            logger.error("%s returned an unexpected response shape: %s", self.display_name, exc)
            return AIResponse(success=False, text="", error="Unexpected response from provider.")

    def _parse_response(self, data: dict) -> AIResponse:  # pragma: no cover - overridden
        raise NotImplementedError


class OpenRouterProvider(_HTTPChatProvider):
    display_name = "OpenRouter"

    def generate(self, request: AIRequest) -> AIResponse:
        if not self.is_configured():
            return AIResponse(success=False, text="", error="No AI provider configured.")
        url = f"{self.base_url or 'https://openrouter.ai/api/v1'}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        messages = []
        if request.system_prompt:
            messages.append({"role": "system", "content": request.system_prompt})
        messages.append({"role": "user", "content": request.prompt})
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": request.temperature,
            "max_tokens": request.max_tokens,
        }
        return self._post_json(url, headers, payload)

    def _parse_response(self, data: dict) -> AIResponse:
        text = data["choices"][0]["message"]["content"]
        return AIResponse(success=True, text=text.strip())


class OpenAIProvider(_HTTPChatProvider):
    display_name = "OpenAI"

    def generate(self, request: AIRequest) -> AIResponse:
        if not self.is_configured():
            return AIResponse(success=False, text="", error="No AI provider configured.")
        url = f"{self.base_url or 'https://api.openai.com/v1'}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        messages = []
        if request.system_prompt:
            messages.append({"role": "system", "content": request.system_prompt})
        messages.append({"role": "user", "content": request.prompt})
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": request.temperature,
            "max_tokens": request.max_tokens,
        }
        return self._post_json(url, headers, payload)

    def _parse_response(self, data: dict) -> AIResponse:
        text = data["choices"][0]["message"]["content"]
        return AIResponse(success=True, text=text.strip())


class AnthropicProvider(_HTTPChatProvider):
    display_name = "Anthropic"

    def generate(self, request: AIRequest) -> AIResponse:
        if not self.is_configured():
            return AIResponse(success=False, text="", error="No AI provider configured.")
        url = f"{self.base_url or 'https://api.anthropic.com/v1'}/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "messages": [{"role": "user", "content": request.prompt}],
        }
        if request.system_prompt:
            payload["system"] = request.system_prompt
        return self._post_json(url, headers, payload)

    def _parse_response(self, data: dict) -> AIResponse:
        text = data["content"][0]["text"]
        return AIResponse(success=True, text=text.strip())


class GoogleGeminiProvider(_HTTPChatProvider):
    display_name = "Google Gemini"

    def generate(self, request: AIRequest) -> AIResponse:
        if not self.is_configured():
            return AIResponse(success=False, text="", error="No AI provider configured.")
        base = self.base_url or "https://generativelanguage.googleapis.com/v1beta"
        url = f"{base}/models/{self.model}:generateContent?key={self.api_key}"
        headers = {"Content-Type": "application/json"}
        prompt_text = request.prompt
        if request.system_prompt:
            prompt_text = f"{request.system_prompt}\n\n{request.prompt}"
        payload = {
            "contents": [{"parts": [{"text": prompt_text}]}],
            "generationConfig": {
                "temperature": request.temperature,
                "maxOutputTokens": request.max_tokens,
            },
        }
        return self._post_json(url, headers, payload)

    def _parse_response(self, data: dict) -> AIResponse:
        text = data["candidates"][0]["content"]["parts"][0]["text"]
        return AIResponse(success=True, text=text.strip())


class OllamaProvider(_HTTPChatProvider):
    display_name = "Ollama"

    def is_configured(self) -> bool:
        # Ollama typically runs locally with no API key required.
        return bool(self.model)

    def generate(self, request: AIRequest) -> AIResponse:
        if not self.is_configured():
            return AIResponse(success=False, text="", error="No AI provider configured.")
        url = f"{self.base_url or 'http://localhost:11434'}/api/generate"
        headers = {"Content-Type": "application/json"}
        prompt_text = request.prompt
        if request.system_prompt:
            prompt_text = f"{request.system_prompt}\n\n{request.prompt}"
        payload = {
            "model": self.model,
            "prompt": prompt_text,
            "stream": False,
            "options": {"temperature": request.temperature},
        }
        return self._post_json(url, headers, payload)

    def _parse_response(self, data: dict) -> AIResponse:
        text = data["response"]
        return AIResponse(success=True, text=text.strip())


class CustomProvider(OpenAIProvider):
    """Any OpenAI-compatible endpoint (self-hosted, proxy, etc)."""

    display_name = "Custom"


_PROVIDER_CLASSES: dict[str, type[_HTTPChatProvider]] = {
    "OpenRouter": OpenRouterProvider,
    "OpenAI": OpenAIProvider,
    "Anthropic": AnthropicProvider,
    "Google Gemini": GoogleGeminiProvider,
    "Ollama": OllamaProvider,
    "Custom": CustomProvider,
}


def get_active_provider() -> AIProvider:
    """Resolve the currently configured provider from settings."""
    from config.settings_manager import settings_manager  # local import avoids cycles

    ai_settings = settings_manager.get_section("ai")
    provider_name = ai_settings.get("provider", "None")
    provider_class = _PROVIDER_CLASSES.get(provider_name)

    if provider_name == "None" or provider_class is None:
        return NoProviderConfigured()

    provider = provider_class(
        base_url=ai_settings.get("base_url", ""),
        api_key=ai_settings.get("api_key", ""),
        model=ai_settings.get("model", ""),
        timeout=int(ai_settings.get("timeout_seconds", 60)),
    )

    if not provider.is_configured():
        return NoProviderConfigured()

    return provider
