"""
Plugin system.

Scans /plugins for .py files exposing a top-level `register(app_window)`
function and calls it, giving plugins a hook into the running app (e.g. to
add their own menu action or background task). This is the real loader
mechanism requested by the spec's "Future Features" list; it doesn't ship
any bundled plugins, but it will actually discover and run one if a user
drops a compatible .py file into /plugins.

Minimal plugin contract:

    # plugins/my_plugin.py
    def register(app_window):
        ...  # do something with the running AppWindow instance
"""

from __future__ import annotations

import importlib.util
import logging

from utils.paths import PLUGINS_DIR

logger = logging.getLogger(__name__)


class PluginManager:
    def __init__(self) -> None:
        self._loaded_plugin_names: list[str] = []

    def load_all(self, app_window) -> None:
        PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
        plugin_files = sorted(p for p in PLUGINS_DIR.glob("*.py") if not p.name.startswith("_"))

        if not plugin_files:
            logger.info("No plugins found in %s.", PLUGINS_DIR)
            return

        for plugin_file in plugin_files:
            self._load_plugin(plugin_file, app_window)

    def _load_plugin(self, plugin_file, app_window) -> None:
        module_name = f"creator_studio_plugin_{plugin_file.stem}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, plugin_file)
            if spec is None or spec.loader is None:
                logger.error("Could not load plugin spec for %s", plugin_file)
                return
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            register_fn = getattr(module, "register", None)
            if register_fn is None:
                logger.warning("Plugin %s has no register(app_window) function; skipping.", plugin_file.name)
                return

            register_fn(app_window)
            self._loaded_plugin_names.append(plugin_file.stem)
            logger.info("Loaded plugin: %s", plugin_file.name)
        except Exception:
            logger.exception("Failed to load plugin %s", plugin_file.name)

    @property
    def loaded_plugin_names(self) -> list[str]:
        return list(self._loaded_plugin_names)


plugin_manager = PluginManager()
