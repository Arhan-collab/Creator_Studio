"""
File watcher background service.

Watches the projects and assets working directories for filesystem changes
using `watchdog`, and logs them to activity_log. This gives the rest of the
app (and future phases) a real, running record of on-disk changes without
polling.
"""

from __future__ import annotations

import logging
import threading

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from database.db_manager import db_manager
from utils.paths import CACHE_DIR, PROJECTS_DIR

logger = logging.getLogger(__name__)


class _ActivityLogHandler(FileSystemEventHandler):
    def __init__(self) -> None:
        super().__init__()
        self._lock = threading.Lock()

    def _log(self, action: str, path: str) -> None:
        with self._lock:
            try:
                db_manager.execute(
                    "INSERT INTO activity_log (action, details) VALUES (?, ?)", (action, path)
                )
            except Exception:
                logger.exception("Failed to record file system event in activity_log")

    def on_created(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._log("file_created", event.src_path)

    def on_deleted(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._log("file_deleted", event.src_path)

    def on_modified(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._log("file_modified", event.src_path)

    def on_moved(self, event: FileSystemEvent) -> None:
        if not event.is_directory:
            self._log("file_moved", f"{event.src_path} -> {event.dest_path}")


class FileWatcherService:
    def __init__(self) -> None:
        self._observer: Observer | None = None

    def start(self) -> None:
        if self._observer is not None:
            return
        handler = _ActivityLogHandler()
        self._observer = Observer()
        for directory in (PROJECTS_DIR, CACHE_DIR):
            directory.mkdir(parents=True, exist_ok=True)
            self._observer.schedule(handler, str(directory), recursive=True)
        self._observer.start()
        logger.info("File watcher started on %s and %s", PROJECTS_DIR, CACHE_DIR)

    def stop(self) -> None:
        if self._observer is not None:
            self._observer.stop()
            self._observer.join(timeout=2)
            self._observer = None
            logger.info("File watcher stopped.")


file_watcher_service = FileWatcherService()
