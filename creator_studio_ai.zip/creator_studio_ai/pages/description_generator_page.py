"""Description Generator: SEO-optimized descriptions with CTA, links, and
timestamp placeholders."""

from __future__ import annotations

import customtkinter as ctk

from modules.generator_page_base import GeneratorPageBase


class DescriptionGeneratorPage(GeneratorPageBase):
    page_key = "description_generator"
    content_type = "description"
    page_title = "Description Generator"
    page_subtitle = "Generate an SEO-friendly description with a call to action."

    def build_form(self, parent: ctk.CTkFrame) -> None:
        row1 = ctk.CTkFrame(parent, fg_color="transparent")
        row1.pack(fill="x", pady=4)
        ctk.CTkLabel(row1, text="Video / content topic", width=170, anchor="w").pack(side="left")
        self._topic_entry = ctk.CTkEntry(row1, placeholder_text="e.g. Full tutorial on color grading in Premiere")
        self._topic_entry.pack(side="left", fill="x", expand=True)

        row2 = ctk.CTkFrame(parent, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Keywords (comma separated)", width=170, anchor="w").pack(side="left")
        self._keywords_entry = ctk.CTkEntry(row2, placeholder_text="e.g. color grading, premiere pro, tutorial")
        self._keywords_entry.pack(side="left", fill="x", expand=True)

        row3 = ctk.CTkFrame(parent, fg_color="transparent")
        row3.pack(fill="x", pady=4)
        ctk.CTkLabel(row3, text="Call to action", width=170, anchor="w").pack(side="left")
        self._cta_entry = ctk.CTkEntry(row3, placeholder_text="e.g. Subscribe for more editing tutorials")
        self._cta_entry.pack(side="left", fill="x", expand=True)

        row4 = ctk.CTkFrame(parent, fg_color="transparent")
        row4.pack(fill="x", pady=4)
        ctk.CTkLabel(row4, text="Links to include", width=170, anchor="w").pack(side="left")
        self._links_entry = ctk.CTkEntry(row4, placeholder_text="e.g. https://instagram.com/you")
        self._links_entry.pack(side="left", fill="x", expand=True)

    def get_topic(self) -> str:
        return self._topic_entry.get().strip()

    def build_prompt(self) -> tuple[str, str]:
        topic = self.get_topic()
        if not topic:
            self.set_status("Enter a topic first.")
            return "", ""

        keywords = self._keywords_entry.get().strip()
        cta = self._cta_entry.get().strip()
        links = self._links_entry.get().strip()

        system_prompt = "You write SEO-optimized video/content descriptions for online creators."
        user_prompt = f"Write an SEO-optimized description for content about: {topic}."
        if keywords:
            user_prompt += f" Naturally include these keywords: {keywords}."
        user_prompt += (
            " Include a placeholder timestamps section (e.g. '00:00 Intro'), "
            "3-5 relevant hashtags at the end,"
        )
        if cta:
            user_prompt += f" and this call to action: {cta}."
        if links:
            user_prompt += f" Include these links: {links}."
        return system_prompt, user_prompt
