"""
Analytics.

Manual tracking of views/likes/comments/subscribers/followers/revenue/
growth/engagement per platform and date. Includes a lightweight trend
chart drawn directly on a tkinter Canvas (kept dependency-free, matching
the approved tech stack) - future phases can swap in live API data without
changing this page's storage model.
"""

from __future__ import annotations

import logging
import tkinter as tk
from datetime import date

import customtkinter as ctk

from config.app_config import ANALYTICS_METRICS, SOCIAL_PLATFORMS
from database.db_manager import db_manager
from modules.base_page import BasePage

logger = logging.getLogger(__name__)

_ALL_PLATFORMS = SOCIAL_PLATFORMS + ["Other"]


class AnalyticsPage(BasePage):
    page_key = "analytics"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._entries_frame: ctk.CTkFrame | None = None
        self._chart_canvas: tk.Canvas | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        header = ctk.CTkLabel(
            self, text="Analytics", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 12))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=24, pady=(0, 16))

        entry_card = ctk.CTkFrame(scroll, corner_radius=12)
        entry_card.pack(fill="x", pady=(0, 12))
        entry_body = ctk.CTkFrame(entry_card, fg_color="transparent")
        entry_body.pack(fill="x", padx=18, pady=16)

        ctk.CTkLabel(entry_body, text="Log a Metric", font=ctk.CTkFont(size=15, weight="bold")).pack(
            anchor="w", pady=(0, 8)
        )

        row1 = ctk.CTkFrame(entry_body, fg_color="transparent")
        row1.pack(fill="x", pady=4)
        ctk.CTkLabel(row1, text="Platform", width=100, anchor="w").pack(side="left")
        self._platform_menu = ctk.CTkOptionMenu(row1, values=_ALL_PLATFORMS)
        self._platform_menu.pack(side="left", padx=(0, 16))
        ctk.CTkLabel(row1, text="Metric", width=80, anchor="w").pack(side="left")
        self._metric_menu = ctk.CTkOptionMenu(row1, values=ANALYTICS_METRICS)
        self._metric_menu.pack(side="left")

        row2 = ctk.CTkFrame(entry_body, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Value", width=100, anchor="w").pack(side="left")
        self._value_entry = ctk.CTkEntry(row2, width=120)
        self._value_entry.pack(side="left", padx=(0, 16))
        ctk.CTkLabel(row2, text="Date", width=80, anchor="w").pack(side="left")
        self._date_entry = ctk.CTkEntry(row2, width=120)
        self._date_entry.insert(0, date.today().isoformat())
        self._date_entry.pack(side="left")

        row3 = ctk.CTkFrame(entry_body, fg_color="transparent")
        row3.pack(fill="x", pady=4)
        ctk.CTkLabel(row3, text="Notes", width=100, anchor="w").pack(side="left")
        self._notes_entry = ctk.CTkEntry(row3)
        self._notes_entry.pack(side="left", fill="x", expand=True)

        self._entry_status_label = ctk.CTkLabel(entry_body, text="", text_color=("gray40", "gray65"))
        self._entry_status_label.pack(anchor="w", pady=(6, 0))

        ctk.CTkButton(entry_body, text="Add Entry", command=self._add_entry).pack(anchor="w", pady=(8, 0))

        chart_card = ctk.CTkFrame(scroll, corner_radius=12)
        chart_card.pack(fill="x", pady=(0, 12))
        chart_body = ctk.CTkFrame(chart_card, fg_color="transparent")
        chart_body.pack(fill="x", padx=18, pady=16)

        ctk.CTkLabel(chart_body, text="Trend", font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w")

        chart_controls = ctk.CTkFrame(chart_body, fg_color="transparent")
        chart_controls.pack(fill="x", pady=(8, 8))
        self._chart_platform_menu = ctk.CTkOptionMenu(
            chart_controls, values=_ALL_PLATFORMS, command=lambda _v: self._draw_chart()
        )
        self._chart_platform_menu.pack(side="left", padx=(0, 8))
        self._chart_metric_menu = ctk.CTkOptionMenu(
            chart_controls, values=ANALYTICS_METRICS, command=lambda _v: self._draw_chart()
        )
        self._chart_metric_menu.pack(side="left")

        self._chart_canvas = tk.Canvas(chart_body, height=220, bg="#1a1a1a", highlightthickness=0)
        self._chart_canvas.pack(fill="x")

        history_card = ctk.CTkFrame(scroll, corner_radius=12)
        history_card.pack(fill="both", expand=True)
        ctk.CTkLabel(
            history_card, text="Recent Entries", font=ctk.CTkFont(size=15, weight="bold"), anchor="w"
        ).pack(fill="x", padx=18, pady=(14, 6))
        self._entries_frame = ctk.CTkFrame(history_card, fg_color="transparent")
        self._entries_frame.pack(fill="both", expand=True, padx=18, pady=(0, 14))

        self.refresh_all()

    def on_show(self) -> None:
        self.refresh_all()

    def refresh_all(self) -> None:
        self._refresh_entries()
        self._draw_chart()

    # -------------------------------------------------------------- Entry

    def _add_entry(self) -> None:
        raw_value = self._value_entry.get().strip()
        event_date = self._date_entry.get().strip()
        try:
            value = float(raw_value)
        except ValueError:
            self._entry_status_label.configure(text="Value must be a number.")
            return
        if not event_date:
            self._entry_status_label.configure(text="Date is required.")
            return

        db_manager.execute(
            """
            INSERT INTO analytics_entries (platform, metric_type, value, recorded_date, notes)
            VALUES (?, ?, ?, ?, ?)
            """,
            (self._platform_menu.get(), self._metric_menu.get(), value, event_date, self._notes_entry.get().strip()),
        )
        self._entry_status_label.configure(text="Entry added.")
        self._value_entry.delete(0, "end")
        self.refresh_all()

    def _refresh_entries(self) -> None:
        for widget in self._entries_frame.winfo_children():
            widget.destroy()

        rows = db_manager.query(
            "SELECT * FROM analytics_entries ORDER BY recorded_date DESC, id DESC LIMIT 25"
        )
        if not rows:
            ctk.CTkLabel(
                self._entries_frame, text="No entries logged yet.", text_color=("gray40", "gray65")
            ).pack(anchor="w")
            return

        for row in rows:
            item = ctk.CTkFrame(self._entries_frame, fg_color=("gray92", "gray17"), corner_radius=8)
            item.pack(fill="x", pady=2)
            text = f"{row['recorded_date']}  \u2022  {row['platform']}  \u2022  {row['metric_type']}: {row['value']:g}"
            if row["notes"]:
                text += f"  \u2014 {row['notes']}"
            ctk.CTkLabel(item, text=text, anchor="w", font=ctk.CTkFont(size=12)).pack(
                side="left", fill="x", expand=True, padx=10, pady=6
            )
            ctk.CTkButton(
                item, text="Delete", width=60, height=24, fg_color="darkred",
                command=lambda eid=row["id"]: self._delete_entry(eid),
            ).pack(side="right", padx=10)

    def _delete_entry(self, entry_id: int) -> None:
        db_manager.execute("DELETE FROM analytics_entries WHERE id = ?", (entry_id,))
        self.refresh_all()

    # -------------------------------------------------------------- Chart

    def _draw_chart(self) -> None:
        canvas = self._chart_canvas
        canvas.delete("all")
        canvas.update_idletasks()
        width = max(canvas.winfo_width(), 400)
        height = 220

        platform = self._chart_platform_menu.get()
        metric = self._chart_metric_menu.get()

        rows = db_manager.query(
            """
            SELECT recorded_date, value FROM analytics_entries
            WHERE platform = ? AND metric_type = ?
            ORDER BY recorded_date ASC
            LIMIT 30
            """,
            (platform, metric),
        )

        if not rows:
            canvas.create_text(
                width // 2, height // 2, text="No data yet for this platform/metric.",
                fill="#999999",
            )
            return

        values = [row["value"] for row in rows]
        labels = [row["recorded_date"][5:] for row in rows]  # MM-DD
        max_value = max(values) or 1
        padding = 40
        plot_width = width - 2 * padding
        plot_height = height - 2 * padding
        bar_count = len(values)
        bar_gap = 6
        bar_width = max((plot_width - bar_gap * (bar_count - 1)) / bar_count, 4) if bar_count else 10

        canvas.create_line(padding, height - padding, width - padding, height - padding, fill="#555555")

        for index, value in enumerate(values):
            bar_height = (value / max_value) * plot_height if max_value else 0
            x0 = padding + index * (bar_width + bar_gap)
            x1 = x0 + bar_width
            y1 = height - padding
            y0 = y1 - bar_height
            canvas.create_rectangle(x0, y0, x1, y1, fill="#3b82f6", outline="")
            if bar_count <= 15:
                canvas.create_text((x0 + x1) / 2, height - padding + 12, text=labels[index], fill="#999999", font=("Arial", 8))

        canvas.create_text(
            padding, padding - 15, text=f"{metric} \u2014 {platform} (max {max_value:g})",
            fill="#cccccc", anchor="w", font=("Arial", 10, "bold"),
        )
