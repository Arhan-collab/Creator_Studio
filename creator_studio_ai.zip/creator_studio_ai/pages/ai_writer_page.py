"""AI Writer: generates YouTube scripts, tutorials, marketing copy, blog
articles, and more, based on a topic and content type."""

from __future__ import annotations

import customtkinter as ctk

from config.app_config import AI_WRITER_CONTENT_TYPES
from modules.generator_page_base import GeneratorPageBase


class AIWriterPage(GeneratorPageBase):
    page_key = "ai_writer"
    content_type = "ai_writer"
    page_title = "AI Writer"
    page_subtitle = "Generate scripts, articles, and marketing copy from a single topic."

    def build_form(self, parent: ctk.CTkFrame) -> None:
        row1 = ctk.CTkFrame(parent, fg_color="transparent")
        row1.pack(fill="x", pady=4)
        ctk.CTkLabel(row1, text="Content type", width=140, anchor="w").pack(side="left")
        self._content_type_menu = ctk.CTkOptionMenu(row1, values=AI_WRITER_CONTENT_TYPES)
        self._content_type_menu.pack(side="left")

        row2 = ctk.CTkFrame(parent, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Topic", width=140, anchor="w").pack(side="left")
        self._topic_entry = ctk.CTkEntry(row2, placeholder_text="e.g. Beginner's guide to sourdough baking")
        self._topic_entry.pack(side="left", fill="x", expand=True)

        row3 = ctk.CTkFrame(parent, fg_color="transparent")
        row3.pack(fill="x", pady=4)
        ctk.CTkLabel(row3, text="Extra notes (optional)", width=140, anchor="w").pack(side="left")
        self._notes_entry = ctk.CTkEntry(row3, placeholder_text="Target audience, length, style, ...")
        self._notes_entry.pack(side="left", fill="x", expand=True)

    def get_topic(self) -> str:
        return self._topic_entry.get().strip()

    def get_platform(self) -> str:
        return self._content_type_menu.get()

    def build_prompt(self) -> tuple[str, str]:
        topic = self.get_topic()
        if not topic:
            self.set_status("Enter a topic first.")
            return "", ""

        content_type = self._content_type_menu.get()
        notes = self._notes_entry.get().strip()

        system_prompt = (
            "You are an expert content writer for online creators. "
            "Write clear, engaging, well-structured content ready to use."
        )
        user_prompt = f"Write a {content_type} about: {topic}."
        if notes:
            user_prompt += f" Additional requirements: {notes}."
        return system_prompt, user_prompt
