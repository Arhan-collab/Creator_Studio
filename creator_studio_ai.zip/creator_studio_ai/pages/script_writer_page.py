"""Script Writer: generates a structured video script (Hook, Intro, Main
Content, Call To Action, Outro) for a given topic and target length."""

from __future__ import annotations

import customtkinter as ctk

from modules.generator_page_base import GeneratorPageBase

_LENGTH_CHOICES = ["Short (under 1 min)", "Medium (3-5 min)", "Long (8-15 min)"]


class ScriptWriterPage(GeneratorPageBase):
    page_key = "script_writer"
    content_type = "script_writer"
    page_title = "Script Writer"
    page_subtitle = "Generate a structured video script: hook, intro, body, and outro."

    def build_form(self, parent: ctk.CTkFrame) -> None:
        row1 = ctk.CTkFrame(parent, fg_color="transparent")
        row1.pack(fill="x", pady=4)
        ctk.CTkLabel(row1, text="Video topic", width=140, anchor="w").pack(side="left")
        self._topic_entry = ctk.CTkEntry(row1, placeholder_text="e.g. Top 5 camera settings for beginners")
        self._topic_entry.pack(side="left", fill="x", expand=True)

        row2 = ctk.CTkFrame(parent, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Target length", width=140, anchor="w").pack(side="left")
        self._length_menu = ctk.CTkOptionMenu(row2, values=_LENGTH_CHOICES)
        self._length_menu.pack(side="left")

        row3 = ctk.CTkFrame(parent, fg_color="transparent")
        row3.pack(fill="x", pady=4)
        ctk.CTkLabel(row3, text="Tone / style", width=140, anchor="w").pack(side="left")
        self._tone_entry = ctk.CTkEntry(row3, placeholder_text="e.g. energetic, casual, expert")
        self._tone_entry.pack(side="left", fill="x", expand=True)

    def get_topic(self) -> str:
        return self._topic_entry.get().strip()

    def get_platform(self) -> str:
        return self._length_menu.get()

    def build_prompt(self) -> tuple[str, str]:
        topic = self.get_topic()
        if not topic:
            self.set_status("Enter a video topic first.")
            return "", ""

        length = self._length_menu.get()
        tone = self._tone_entry.get().strip() or "engaging and clear"

        system_prompt = (
            "You are a professional video scriptwriter for online creators. "
            "Always structure scripts with clearly labeled sections: "
            "HOOK, INTRO, MAIN CONTENT, CALL TO ACTION, OUTRO."
        )
        user_prompt = (
            f"Write a {length} video script about: {topic}. "
            f"Tone: {tone}. Label each section clearly in all caps followed by a colon."
        )
        return system_prompt, user_prompt
