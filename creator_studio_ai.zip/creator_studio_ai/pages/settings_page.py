"""
Settings page.

Every control here is wired to real, persisted behavior:
- Appearance changes apply immediately via ThemeManager.
- Autosave toggle/interval control the real AutosaveService.
- "Backup Now" performs a real file-copy backup via BackupService.
- AI provider fields persist to settings.json under "ai"; actual provider
  API calls are implemented in a later phase (see services/ai/ai_provider.py
  for the interface and the current "No AI provider configured" behavior).
"""

from __future__ import annotations

import logging
from tkinter import filedialog

import customtkinter as ctk

from config.app_config import AI_PROVIDER_CHOICES, THEME_CHOICES
from config.settings_manager import settings_manager
from modules.base_page import BasePage
from modules.theme_manager import theme_manager
from services.backup_service import backup_service

logger = logging.getLogger(__name__)


class SettingsPage(BasePage):
    page_key = "settings"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._status_label: ctk.CTkLabel | None = None
        self._build_ui()

    # ------------------------------------------------------------------ UI

    def _build_ui(self) -> None:
        header = ctk.CTkLabel(
            self, text="Settings", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 8))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=24, pady=(0, 20))

        self._build_appearance_section(scroll)
        self._build_autosave_section(scroll)
        self._build_backup_section(scroll)
        self._build_ai_section(scroll)
        self._build_export_section(scroll)

        self._status_label = ctk.CTkLabel(self, text="", text_color=("gray30", "gray70"))
        self._status_label.pack(fill="x", padx=24, pady=(0, 12))

    def _section(self, parent: ctk.CTkBaseClass, title: str) -> ctk.CTkFrame:
        card = ctk.CTkFrame(parent, corner_radius=12)
        card.pack(fill="x", pady=8)
        ctk.CTkLabel(
            card, text=title, font=ctk.CTkFont(size=16, weight="bold"), anchor="w"
        ).pack(fill="x", padx=18, pady=(14, 8))
        body = ctk.CTkFrame(card, fg_color="transparent")
        body.pack(fill="x", padx=18, pady=(0, 16))
        return body

    # ------------------------------------------------------------ Sections

    def _build_appearance_section(self, parent: ctk.CTkBaseClass) -> None:
        body = self._section(parent, "Appearance")

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x", pady=4)
        ctk.CTkLabel(row, text="Theme", width=160, anchor="w").pack(side="left")

        theme_menu = ctk.CTkOptionMenu(
            row,
            values=THEME_CHOICES,
            command=self._on_theme_changed,
        )
        theme_menu.set(settings_manager.get("appearance", "theme", "Dark"))
        theme_menu.pack(side="left")

    def _build_autosave_section(self, parent: ctk.CTkBaseClass) -> None:
        body = self._section(parent, "Autosave")
        autosave_settings = settings_manager.get_section("autosave")

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x", pady=4)

        self._autosave_switch = ctk.CTkSwitch(
            row, text="Enable autosave", command=self._on_autosave_toggle
        )
        if autosave_settings.get("enabled", True):
            self._autosave_switch.select()
        self._autosave_switch.pack(side="left", padx=(0, 24))

        ctk.CTkLabel(row, text="Interval (seconds)").pack(side="left", padx=(0, 8))
        self._autosave_interval_entry = ctk.CTkEntry(row, width=80)
        self._autosave_interval_entry.insert(0, str(autosave_settings.get("interval_seconds", 60)))
        self._autosave_interval_entry.pack(side="left", padx=(0, 8))

        ctk.CTkButton(row, text="Save", width=80, command=self._on_autosave_interval_save).pack(
            side="left"
        )

    def _build_backup_section(self, parent: ctk.CTkBaseClass) -> None:
        body = self._section(parent, "Backups")
        backup_settings = settings_manager.get_section("backups")

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x", pady=4)

        ctk.CTkButton(row, text="Backup Now", command=self._on_backup_now).pack(side="left")

        last_backup = backup_settings.get("last_backup_at") or "Never"
        self._last_backup_label = ctk.CTkLabel(row, text=f"Last backup: {last_backup}")
        self._last_backup_label.pack(side="left", padx=(16, 0))

    def _build_ai_section(self, parent: ctk.CTkBaseClass) -> None:
        body = self._section(parent, "AI Settings")
        ai_settings = settings_manager.get_section("ai")

        note = ctk.CTkLabel(
            body,
            text=(
                "No API key is stored anywhere except locally in your own config file. "
                "Leave the API key blank to keep AI features disabled."
            ),
            text_color=("gray40", "gray65"),
            wraplength=560,
            justify="left",
            anchor="w",
        )
        note.pack(fill="x", pady=(0, 10))

        self._ai_provider_menu = self._labeled_option_menu(
            body, "Provider", AI_PROVIDER_CHOICES, ai_settings.get("provider", "None")
        )
        self._ai_base_url_entry = self._labeled_entry(body, "Base URL", ai_settings.get("base_url", ""))
        self._ai_api_key_entry = self._labeled_entry(
            body, "API Key", ai_settings.get("api_key", ""), show="*"
        )
        self._ai_model_entry = self._labeled_entry(body, "Model", ai_settings.get("model", ""))
        self._ai_timeout_entry = self._labeled_entry(
            body, "Timeout (seconds)", str(ai_settings.get("timeout_seconds", 60))
        )

        temp_row = ctk.CTkFrame(body, fg_color="transparent")
        temp_row.pack(fill="x", pady=4)
        ctk.CTkLabel(temp_row, text="Temperature", width=160, anchor="w").pack(side="left")
        self._ai_temperature_slider = ctk.CTkSlider(temp_row, from_=0.0, to=1.5, number_of_steps=15)
        self._ai_temperature_slider.set(float(ai_settings.get("temperature", 0.7)))
        self._ai_temperature_slider.pack(side="left", fill="x", expand=True, padx=(0, 12))
        self._ai_temperature_value_label = ctk.CTkLabel(temp_row, text=f"{ai_settings.get('temperature', 0.7):.2f}")
        self._ai_temperature_value_label.pack(side="left")
        self._ai_temperature_slider.configure(command=self._on_temperature_slide)

        ctk.CTkButton(body, text="Save AI Settings", command=self._on_save_ai_settings).pack(
            anchor="w", pady=(12, 0)
        )

    def _build_export_section(self, parent: ctk.CTkBaseClass) -> None:
        body = self._section(parent, "Export")
        ctk.CTkButton(
            body, text="Export Settings to File", command=self._on_export_settings
        ).pack(anchor="w")

    # -------------------------------------------------------------- Helpers

    def _labeled_entry(
        self, parent: ctk.CTkBaseClass, label: str, initial_value: str, show: str | None = None
    ) -> ctk.CTkEntry:
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=4)
        ctk.CTkLabel(row, text=label, width=160, anchor="w").pack(side="left")
        entry = ctk.CTkEntry(row, show=show or "")
        entry.insert(0, initial_value)
        entry.pack(side="left", fill="x", expand=True)
        return entry

    def _labeled_option_menu(
        self, parent: ctk.CTkBaseClass, label: str, values: list[str], initial_value: str
    ) -> ctk.CTkOptionMenu:
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", pady=4)
        ctk.CTkLabel(row, text=label, width=160, anchor="w").pack(side="left")
        menu = ctk.CTkOptionMenu(row, values=values)
        menu.set(initial_value if initial_value in values else values[0])
        menu.pack(side="left")
        return menu

    def _set_status(self, message: str) -> None:
        if self._status_label is not None:
            self._status_label.configure(text=message)

    # ------------------------------------------------------------- Handlers

    def _on_theme_changed(self, new_mode: str) -> None:
        theme_manager.set_mode(new_mode)
        self._set_status(f"Theme set to {new_mode}.")

    def _on_autosave_toggle(self) -> None:
        enabled = bool(self._autosave_switch.get())
        settings_manager.set("autosave", "enabled", enabled)
        self._set_status(f"Autosave {'enabled' if enabled else 'disabled'}.")

    def _on_autosave_interval_save(self) -> None:
        raw_value = self._autosave_interval_entry.get().strip()
        try:
            interval = max(int(raw_value), 5)
        except ValueError:
            self._set_status("Autosave interval must be a whole number of seconds.")
            return
        settings_manager.set("autosave", "interval_seconds", interval)
        self._set_status(f"Autosave interval set to {interval} seconds.")

    def _on_backup_now(self) -> None:
        try:
            destination = backup_service.create_backup()
            self._last_backup_label.configure(
                text=f"Last backup: {settings_manager.get('backups', 'last_backup_at')}"
            )
            self._set_status(f"Backup created: {destination.name}")
        except FileNotFoundError as exc:
            logger.error("Backup failed: %s", exc)
            self._set_status("Backup failed: database file not found yet.")

    def _on_temperature_slide(self, value: float) -> None:
        self._ai_temperature_value_label.configure(text=f"{float(value):.2f}")

    def _on_save_ai_settings(self) -> None:
        raw_timeout = self._ai_timeout_entry.get().strip()
        try:
            timeout_seconds = max(int(raw_timeout), 1)
        except ValueError:
            self._set_status("Timeout must be a whole number of seconds.")
            return

        settings_manager.update_section(
            "ai",
            {
                "provider": self._ai_provider_menu.get(),
                "base_url": self._ai_base_url_entry.get().strip(),
                "api_key": self._ai_api_key_entry.get().strip(),
                "model": self._ai_model_entry.get().strip(),
                "timeout_seconds": timeout_seconds,
                "temperature": round(float(self._ai_temperature_slider.get()), 2),
            },
        )
        self._set_status("AI settings saved.")
        logger.info(
            "AI settings updated (provider=%s, api_key_set=%s)",
            self._ai_provider_menu.get(),
            bool(self._ai_api_key_entry.get().strip()),
        )

    def _on_export_settings(self) -> None:
        destination = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")],
            initialfile="creator_studio_settings.json",
        )
        if not destination:
            return
        settings_manager.export_to_file(destination)
        self._set_status(f"Settings exported to {destination}")
