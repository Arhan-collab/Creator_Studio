"""Title Generator: SEO, trending, click-worthy, and professional title
variations for a given topic."""

from __future__ import annotations

import customtkinter as ctk

from modules.generator_page_base import GeneratorPageBase

_STYLE_CHOICES = ["SEO-Optimized", "Trending", "Click-worthy", "Professional"]


class TitleGeneratorPage(GeneratorPageBase):
    page_key = "title_generator"
    content_type = "title"
    page_title = "Title Generator"
    page_subtitle = "Generate multiple title variations for your content."

    def build_form(self, parent: ctk.CTkFrame) -> None:
        row1 = ctk.CTkFrame(parent, fg_color="transparent")
        row1.pack(fill="x", pady=4)
        ctk.CTkLabel(row1, text="Video / content topic", width=160, anchor="w").pack(side="left")
        self._topic_entry = ctk.CTkEntry(row1, placeholder_text="e.g. How I edit videos in DaVinci Resolve")
        self._topic_entry.pack(side="left", fill="x", expand=True)

        row2 = ctk.CTkFrame(parent, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Style", width=160, anchor="w").pack(side="left")
        self._style_menu = ctk.CTkOptionMenu(row2, values=_STYLE_CHOICES)
        self._style_menu.pack(side="left")

        row3 = ctk.CTkFrame(parent, fg_color="transparent")
        row3.pack(fill="x", pady=4)
        ctk.CTkLabel(row3, text="How many variations", width=160, anchor="w").pack(side="left")
        self._count_entry = ctk.CTkEntry(row3, width=60)
        self._count_entry.insert(0, "8")
        self._count_entry.pack(side="left")

    def get_topic(self) -> str:
        return self._topic_entry.get().strip()

    def get_platform(self) -> str:
        return self._style_menu.get()

    def build_prompt(self) -> tuple[str, str]:
        topic = self.get_topic()
        if not topic:
            self.set_status("Enter a topic first.")
            return "", ""

        style = self._style_menu.get()
        try:
            count = max(1, min(int(self._count_entry.get().strip() or 8), 25))
        except ValueError:
            count = 8

        system_prompt = "You write high-performing video/content titles for online creators."
        user_prompt = (
            f"Generate {count} {style.lower()} title variations for content about: {topic}. "
            "Return them as a plain numbered list, one title per line, no extra commentary."
        )
        return system_prompt, user_prompt
