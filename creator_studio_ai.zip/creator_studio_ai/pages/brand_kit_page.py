"""
Brand Kit.

A single place to store a creator's brand identity: color palette, logo
files, font files, watermark images, social links, and a free-form brand
guidelines note. Everything is stored in brand_kit_items, keyed by
item_type, so it survives restarts and can be reused by future phases
(e.g. Thumbnail Studio pulling brand colors automatically).
"""

from __future__ import annotations

import logging
import webbrowser
from pathlib import Path
from tkinter import colorchooser, filedialog

import customtkinter as ctk

from database.db_manager import db_manager
from modules.base_page import BasePage

logger = logging.getLogger(__name__)


class BrandKitPage(BasePage):
    page_key = "brand_kit"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        header = ctk.CTkLabel(
            self, text="Brand Kit", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 8))

        self._tabview = ctk.CTkTabview(self)
        self._tabview.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        for tab_name in ["Colors", "Logos", "Fonts", "Watermarks", "Social Links", "Guidelines"]:
            self._tabview.add(tab_name)

        self._build_item_tab(self._tabview.tab("Colors"), "color", is_color=True)
        self._build_item_tab(self._tabview.tab("Logos"), "logo", is_file=True)
        self._build_item_tab(self._tabview.tab("Fonts"), "font", is_file=True)
        self._build_item_tab(self._tabview.tab("Watermarks"), "watermark", is_file=True)
        self._build_item_tab(self._tabview.tab("Social Links"), "social_link", is_url=True)
        self._build_guidelines_tab(self._tabview.tab("Guidelines"))

    def on_show(self) -> None:
        pass  # sub-tabs refresh themselves on build; lists are re-queried on each add/delete

    # ------------------------------------------------------- Generic items

    def _build_item_tab(
        self, tab: ctk.CTkFrame, item_type: str, is_color: bool = False, is_file: bool = False, is_url: bool = False
    ) -> None:
        add_row = ctk.CTkFrame(tab, fg_color="transparent")
        add_row.pack(fill="x", padx=12, pady=(12, 6))

        label_entry = ctk.CTkEntry(add_row, placeholder_text="Label (e.g. Primary, Main Logo, Instagram)")
        label_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))

        list_frame = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        list_frame.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        def refresh() -> None:
            for widget in list_frame.winfo_children():
                widget.destroy()
            rows = db_manager.query(
                "SELECT * FROM brand_kit_items WHERE item_type = ? ORDER BY id DESC", (item_type,)
            )
            if not rows:
                ctk.CTkLabel(list_frame, text="Nothing added yet.", text_color=("gray40", "gray65")).pack(
                    anchor="w"
                )
                return
            for row in rows:
                item = ctk.CTkFrame(list_frame, fg_color=("gray92", "gray17"), corner_radius=8)
                item.pack(fill="x", pady=2)

                if is_color:
                    swatch = ctk.CTkFrame(item, width=28, height=28, fg_color=row["value"], corner_radius=6)
                    swatch.pack(side="left", padx=10, pady=6)
                    swatch.pack_propagate(False)

                text = f"{row['label']}"
                if is_color or is_url:
                    text += f"  \u2014  {row['value']}"
                elif is_file:
                    text += f"  \u2014  {Path(row['value']).name}"

                ctk.CTkLabel(item, text=text, anchor="w").pack(side="left", fill="x", expand=True, padx=10, pady=6)

                if is_url and row["value"]:
                    ctk.CTkButton(
                        item, text="Open", width=60, height=24,
                        command=lambda u=row["value"]: webbrowser.open(u),
                    ).pack(side="right", padx=(0, 6))

                ctk.CTkButton(
                    item, text="Delete", width=60, height=24, fg_color="darkred",
                    command=lambda iid=row["id"]: (
                        db_manager.execute("DELETE FROM brand_kit_items WHERE id = ?", (iid,)),
                        refresh(),
                    ),
                ).pack(side="right", padx=(0, 6))

        def add_item() -> None:
            label = label_entry.get().strip()
            if not label:
                return

            if is_color:
                color = colorchooser.askcolor(title="Choose brand color")
                if not color or not color[1]:
                    return
                value = color[1]
            elif is_file:
                path = filedialog.askopenfilename(title=f"Select {item_type} file")
                if not path:
                    return
                value = path
            elif is_url:
                value = url_entry.get().strip()
                if not value:
                    return
            else:
                value = ""

            db_manager.execute(
                "INSERT INTO brand_kit_items (item_type, label, value) VALUES (?, ?, ?)",
                (item_type, label, value),
            )
            label_entry.delete(0, "end")
            if is_url:
                url_entry.delete(0, "end")
            refresh()

        if is_url:
            url_entry = ctk.CTkEntry(add_row, placeholder_text="https://...")
            url_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))

        button_text = {"color": "Pick Color", }.get(item_type, "Add")
        if is_color:
            button_text = "Pick Color"
        elif is_file:
            button_text = "Choose File"
        else:
            button_text = "Add"

        ctk.CTkButton(add_row, text=button_text, width=110, command=add_item).pack(side="left")

        refresh()

    # ------------------------------------------------------------ Guidelines

    def _build_guidelines_tab(self, tab: ctk.CTkFrame) -> None:
        ctk.CTkLabel(
            tab, text="Brand voice, do's and don'ts, usage notes...", text_color=("gray40", "gray65")
        ).pack(anchor="w", padx=12, pady=(12, 4))

        text_box = ctk.CTkTextbox(tab, wrap="word")
        text_box.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        existing = db_manager.query_one(
            "SELECT * FROM brand_kit_items WHERE item_type = 'guidelines' AND label = 'main'"
        )
        if existing:
            text_box.insert("1.0", existing["value"])

        def save() -> None:
            content = text_box.get("1.0", "end").strip()
            if existing:
                db_manager.execute(
                    "UPDATE brand_kit_items SET value = ? WHERE id = ?", (content, existing["id"])
                )
            else:
                db_manager.execute(
                    "INSERT INTO brand_kit_items (item_type, label, value) VALUES ('guidelines', 'main', ?)",
                    (content,),
                )

        ctk.CTkButton(tab, text="Save Guidelines", command=save).pack(anchor="w", padx=12, pady=(0, 12))
