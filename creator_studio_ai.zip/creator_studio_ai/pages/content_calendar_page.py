"""
Content Calendar.

Monthly grid view (built with Python's stdlib `calendar` module) showing
scheduled uploads/deadlines/reminders from calendar_events. Click a day to
add an event; existing events on a day can be edited or deleted.
"""

from __future__ import annotations

import calendar
import logging
from datetime import date, datetime

import customtkinter as ctk

from database.db_manager import db_manager
from modules.base_page import BasePage

logger = logging.getLogger(__name__)

_EVENT_TYPES = ["Upload", "Deadline", "Reminder", "Meeting", "Other"]
_EVENT_COLORS = {
    "Upload": "#2563eb",
    "Deadline": "#dc2626",
    "Reminder": "#d97706",
    "Meeting": "#7c3aed",
    "Other": "#4b5563",
}


class ContentCalendarPage(BasePage):
    page_key = "content_calendar"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        today = date.today()
        self._view_year = today.year
        self._view_month = today.month
        self._grid_frame: ctk.CTkFrame | None = None
        self._month_label: ctk.CTkLabel | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        header_row = ctk.CTkFrame(self, fg_color="transparent")
        header_row.pack(fill="x", padx=24, pady=(20, 8))
        ctk.CTkLabel(
            header_row, text="Content Calendar", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        ).pack(side="left")
        ctk.CTkButton(header_row, text="+ New Event", command=lambda: self._open_event_dialog()).pack(
            side="right"
        )

        nav_row = ctk.CTkFrame(self, fg_color="transparent")
        nav_row.pack(fill="x", padx=24, pady=(0, 10))
        ctk.CTkButton(nav_row, text="\u2039 Prev", width=80, command=self._go_previous_month).pack(side="left")
        self._month_label = ctk.CTkLabel(nav_row, text="", font=ctk.CTkFont(size=16, weight="bold"))
        self._month_label.pack(side="left", expand=True)
        ctk.CTkButton(nav_row, text="Next \u203a", width=80, command=self._go_next_month).pack(side="right")

        self._grid_frame = ctk.CTkFrame(self, fg_color="transparent")
        self._grid_frame.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        self.refresh_calendar()

    def on_show(self) -> None:
        self.refresh_calendar()

    def _go_previous_month(self) -> None:
        self._view_month -= 1
        if self._view_month < 1:
            self._view_month = 12
            self._view_year -= 1
        self.refresh_calendar()

    def _go_next_month(self) -> None:
        self._view_month += 1
        if self._view_month > 12:
            self._view_month = 1
            self._view_year += 1
        self.refresh_calendar()

    def refresh_calendar(self) -> None:
        for widget in self._grid_frame.winfo_children():
            widget.destroy()

        self._month_label.configure(
            text=f"{calendar.month_name[self._view_month]} {self._view_year}"
        )

        events_by_day: dict[int, list] = {}
        rows = db_manager.query(
            "SELECT * FROM calendar_events WHERE event_date LIKE ? ORDER BY event_date",
            (f"{self._view_year:04d}-{self._view_month:02d}-%",),
        )
        for row in rows:
            day = int(row["event_date"].split("-")[2])
            events_by_day.setdefault(day, []).append(row)

        weekday_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        for col, name in enumerate(weekday_names):
            ctk.CTkLabel(self._grid_frame, text=name, font=ctk.CTkFont(weight="bold")).grid(
                row=0, column=col, sticky="ew", padx=2, pady=2
            )
            self._grid_frame.grid_columnconfigure(col, weight=1, uniform="cal_col")

        month_weeks = calendar.monthcalendar(self._view_year, self._view_month)
        today = date.today()

        for week_index, week in enumerate(month_weeks, start=1):
            self._grid_frame.grid_rowconfigure(week_index, weight=1, uniform="cal_row")
            for col, day in enumerate(week):
                cell = ctk.CTkFrame(self._grid_frame, corner_radius=8, fg_color=("gray92", "gray17"))
                cell.grid(row=week_index, column=col, sticky="nsew", padx=2, pady=2)
                if day == 0:
                    continue

                is_today = (
                    day == today.day and self._view_month == today.month and self._view_year == today.year
                )
                day_label = ctk.CTkLabel(
                    cell,
                    text=str(day),
                    font=ctk.CTkFont(weight="bold" if is_today else "normal"),
                    text_color=("blue", "#66aaff") if is_today else None,
                )
                day_label.pack(anchor="ne", padx=6, pady=4)
                day_label.bind("<Button-1>", lambda _e, d=day: self._open_event_dialog(day=d))
                cell.bind("<Button-1>", lambda _e, d=day: self._open_event_dialog(day=d))

                for event_row in events_by_day.get(day, [])[:3]:
                    chip = ctk.CTkButton(
                        cell,
                        text=event_row["title"][:18],
                        height=20,
                        fg_color=_EVENT_COLORS.get(event_row["event_type"], "#4b5563"),
                        font=ctk.CTkFont(size=10),
                        command=lambda eid=event_row["id"]: self._open_event_dialog(event_id=eid),
                    )
                    chip.pack(fill="x", padx=4, pady=1)

                extra_count = len(events_by_day.get(day, [])) - 3
                if extra_count > 0:
                    ctk.CTkLabel(cell, text=f"+{extra_count} more", font=ctk.CTkFont(size=9)).pack(
                        anchor="w", padx=4
                    )

    # -------------------------------------------------------------- Dialog

    def _open_event_dialog(self, day: int | None = None, event_id: int | None = None) -> None:
        existing = None
        if event_id is not None:
            existing = db_manager.query_one("SELECT * FROM calendar_events WHERE id = ?", (event_id,))

        if existing:
            initial_date = existing["event_date"]
        elif day is not None:
            initial_date = f"{self._view_year:04d}-{self._view_month:02d}-{day:02d}"
        else:
            initial_date = date.today().isoformat()

        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Event" if existing else "New Event")
        dialog.geometry("380x420")
        dialog.resizable(False, False)
        dialog.grab_set()

        ctk.CTkLabel(dialog, text="Title", anchor="w").pack(fill="x", padx=20, pady=(20, 2))
        title_entry = ctk.CTkEntry(dialog)
        title_entry.insert(0, existing["title"] if existing else "")
        title_entry.pack(fill="x", padx=20)

        ctk.CTkLabel(dialog, text="Date (YYYY-MM-DD)", anchor="w").pack(fill="x", padx=20, pady=(10, 2))
        date_entry = ctk.CTkEntry(dialog)
        date_entry.insert(0, initial_date)
        date_entry.pack(fill="x", padx=20)

        ctk.CTkLabel(dialog, text="Type", anchor="w").pack(fill="x", padx=20, pady=(10, 2))
        type_menu = ctk.CTkOptionMenu(dialog, values=_EVENT_TYPES)
        type_menu.set(existing["event_type"] if existing else _EVENT_TYPES[0])
        type_menu.pack(fill="x", padx=20)

        ctk.CTkLabel(dialog, text="Notes", anchor="w").pack(fill="x", padx=20, pady=(10, 2))
        notes_box = ctk.CTkTextbox(dialog, height=100)
        notes_box.insert("1.0", existing["description"] if existing else "")
        notes_box.pack(fill="x", padx=20)

        error_label = ctk.CTkLabel(dialog, text="", text_color="red")
        error_label.pack(fill="x", padx=20, pady=(6, 0))

        def save() -> None:
            title = title_entry.get().strip()
            event_date = date_entry.get().strip()
            if not title:
                error_label.configure(text="Title is required.")
                return
            try:
                datetime.strptime(event_date, "%Y-%m-%d")
            except ValueError:
                error_label.configure(text="Date must be in YYYY-MM-DD format.")
                return

            description = notes_box.get("1.0", "end").strip()
            if existing:
                db_manager.execute(
                    "UPDATE calendar_events SET title = ?, description = ?, event_date = ?, event_type = ? WHERE id = ?",
                    (title, description, event_date, type_menu.get(), existing["id"]),
                )
            else:
                db_manager.execute(
                    "INSERT INTO calendar_events (title, description, event_date, event_type) VALUES (?, ?, ?, ?)",
                    (title, description, event_date, type_menu.get()),
                )
            dialog.destroy()
            self.refresh_calendar()

        button_row = ctk.CTkFrame(dialog, fg_color="transparent")
        button_row.pack(fill="x", padx=20, pady=(14, 20))
        ctk.CTkButton(button_row, text="Save", command=save).pack(side="left", fill="x", expand=True, padx=(0, 6))
        if existing:
            def delete() -> None:
                db_manager.execute("DELETE FROM calendar_events WHERE id = ?", (existing["id"],))
                dialog.destroy()
                self.refresh_calendar()

            ctk.CTkButton(button_row, text="Delete", fg_color="darkred", command=delete).pack(
                side="left", fill="x", expand=True
            )
