"""
Dashboard page.

Every widget here reads real, live data:
- Today's Tasks / Recent Projects / Project Statistics come from SQLite.
- Storage Usage and Performance come from psutil / shutil.
- Quick Actions (New Project) actually inserts into the database.

Nothing on this page is mocked or hardcoded sample data.
"""

from __future__ import annotations

import logging
import shutil
from datetime import date, datetime

import customtkinter as ctk
import psutil

from database.db_manager import db_manager
from modules.base_page import BasePage
from utils.paths import BASE_DIR

logger = logging.getLogger(__name__)


class DashboardPage(BasePage):
    page_key = "dashboard"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._build_ui()
        self.refresh_data()

    # ------------------------------------------------------------------ UI

    def _build_ui(self) -> None:
        header = ctk.CTkLabel(
            self, text="Dashboard", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 4))

        subheader = ctk.CTkLabel(
            self,
            text="An overview of your workspace.",
            font=ctk.CTkFont(size=13),
            text_color=("gray40", "gray65"),
            anchor="w",
        )
        subheader.pack(fill="x", padx=24, pady=(0, 16))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        scroll.grid_columnconfigure((0, 1), weight=1, uniform="col")

        # Row 0: Quick actions
        self._quick_actions_card = self._make_card(scroll, "Quick Actions")
        self._quick_actions_card.grid(row=0, column=0, columnspan=2, sticky="ew", padx=8, pady=8)
        self._build_quick_actions(self._quick_actions_card)

        # Row 1: Today's tasks | Recent projects
        self._tasks_card = self._make_card(scroll, "Today's Tasks")
        self._tasks_card.grid(row=1, column=0, sticky="nsew", padx=8, pady=8)

        self._projects_card = self._make_card(scroll, "Recent Projects")
        self._projects_card.grid(row=1, column=1, sticky="nsew", padx=8, pady=8)

        # Row 2: Project statistics | Storage usage
        self._stats_card = self._make_card(scroll, "Project Statistics")
        self._stats_card.grid(row=2, column=0, sticky="nsew", padx=8, pady=8)

        self._storage_card = self._make_card(scroll, "Storage Usage")
        self._storage_card.grid(row=2, column=1, sticky="nsew", padx=8, pady=8)

        # Row 3: Performance widget (full width)
        self._performance_card = self._make_card(scroll, "Performance")
        self._performance_card.grid(row=3, column=0, columnspan=2, sticky="ew", padx=8, pady=8)

    def _make_card(self, parent: ctk.CTkBaseClass, title: str) -> ctk.CTkFrame:
        card = ctk.CTkFrame(parent, corner_radius=12)
        title_label = ctk.CTkLabel(
            card, text=title, font=ctk.CTkFont(size=15, weight="bold"), anchor="w"
        )
        title_label.pack(fill="x", padx=16, pady=(14, 6))
        body = ctk.CTkFrame(card, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=16, pady=(0, 14))
        card.body = body  # type: ignore[attr-defined]
        return card

    def _build_quick_actions(self, card: ctk.CTkFrame) -> None:
        row = ctk.CTkFrame(card.body, fg_color="transparent")  # type: ignore[attr-defined]
        row.pack(fill="x")
        ctk.CTkButton(
            row, text="+ New Project", command=self._open_new_project_dialog, width=160
        ).pack(side="left", padx=(0, 8))
        ctk.CTkButton(
            row, text="Refresh", command=self.refresh_data, width=120, fg_color="gray40"
        ).pack(side="left")

    # ------------------------------------------------------------ Refresh

    def on_show(self) -> None:
        self.refresh_data()

    def refresh_data(self) -> None:
        try:
            self._refresh_tasks()
            self._refresh_recent_projects()
            self._refresh_project_stats()
            self._refresh_storage_usage()
            self._refresh_performance()
        except Exception:
            logger.exception("Failed to refresh dashboard data")

    def _clear(self, frame: ctk.CTkFrame) -> None:
        for widget in frame.winfo_children():
            widget.destroy()

    def _refresh_tasks(self) -> None:
        body = self._tasks_card.body  # type: ignore[attr-defined]
        self._clear(body)
        today_str = date.today().isoformat()
        rows = db_manager.query(
            "SELECT title FROM tasks WHERE due_date = ? AND is_done = 0 ORDER BY id",
            (today_str,),
        )
        if not rows:
            ctk.CTkLabel(
                body, text="No tasks due today.", text_color=("gray40", "gray65")
            ).pack(anchor="w")
            return
        for row in rows:
            ctk.CTkLabel(body, text=f"•  {row['title']}", anchor="w").pack(fill="x", pady=1)

    def _refresh_recent_projects(self) -> None:
        body = self._projects_card.body  # type: ignore[attr-defined]
        self._clear(body)
        rows = db_manager.query(
            "SELECT name, project_type, updated_at FROM projects ORDER BY updated_at DESC LIMIT 5"
        )
        if not rows:
            ctk.CTkLabel(
                body,
                text="No projects yet. Use \u201c+ New Project\u201d to create one.",
                text_color=("gray40", "gray65"),
                wraplength=320,
                justify="left",
            ).pack(anchor="w")
            return
        for row in rows:
            ctk.CTkLabel(
                body,
                text=f"•  {row['name']}  ({row['project_type']})",
                anchor="w",
            ).pack(fill="x", pady=1)

    def _refresh_project_stats(self) -> None:
        body = self._stats_card.body  # type: ignore[attr-defined]
        self._clear(body)
        total_row = db_manager.query_one("SELECT COUNT(*) AS c FROM projects")
        total = total_row["c"] if total_row else 0

        status_rows = db_manager.query(
            "SELECT status, COUNT(*) AS c FROM projects GROUP BY status ORDER BY c DESC"
        )

        ctk.CTkLabel(
            body, text=f"Total projects: {total}", font=ctk.CTkFont(weight="bold")
        ).pack(anchor="w", pady=(0, 4))

        if not status_rows:
            ctk.CTkLabel(
                body, text="No status breakdown yet.", text_color=("gray40", "gray65")
            ).pack(anchor="w")
            return

        for row in status_rows:
            ctk.CTkLabel(body, text=f"{row['status']}: {row['c']}", anchor="w").pack(
                fill="x", pady=1
            )

    def _refresh_storage_usage(self) -> None:
        body = self._storage_card.body  # type: ignore[attr-defined]
        self._clear(body)
        try:
            usage = shutil.disk_usage(str(BASE_DIR))
            used_gb = usage.used / (1024**3)
            total_gb = usage.total / (1024**3)
            fraction = usage.used / usage.total if usage.total else 0

            ctk.CTkLabel(
                body, text=f"{used_gb:.1f} GB used of {total_gb:.1f} GB", anchor="w"
            ).pack(anchor="w", pady=(0, 6))

            progress = ctk.CTkProgressBar(body)
            progress.set(min(max(fraction, 0.0), 1.0))
            progress.pack(fill="x")
        except OSError as exc:
            logger.error("Could not read disk usage: %s", exc)
            ctk.CTkLabel(body, text="Storage info unavailable.").pack(anchor="w")

    def _refresh_performance(self) -> None:
        body = self._performance_card.body  # type: ignore[attr-defined]
        self._clear(body)

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x")

        cpu_percent = psutil.cpu_percent(interval=0.1)
        mem = psutil.virtual_memory()

        cpu_frame = ctk.CTkFrame(row, fg_color="transparent")
        cpu_frame.pack(side="left", fill="x", expand=True, padx=(0, 12))
        ctk.CTkLabel(cpu_frame, text=f"CPU: {cpu_percent:.0f}%", anchor="w").pack(anchor="w")
        cpu_bar = ctk.CTkProgressBar(cpu_frame)
        cpu_bar.set(cpu_percent / 100)
        cpu_bar.pack(fill="x", pady=(4, 0))

        mem_frame = ctk.CTkFrame(row, fg_color="transparent")
        mem_frame.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(mem_frame, text=f"Memory: {mem.percent:.0f}%", anchor="w").pack(anchor="w")
        mem_bar = ctk.CTkProgressBar(mem_frame)
        mem_bar.set(mem.percent / 100)
        mem_bar.pack(fill="x", pady=(4, 0))

    # ------------------------------------------------------------- Actions

    def _open_new_project_dialog(self) -> None:
        dialog = ctk.CTkToplevel(self)
        dialog.title("New Project")
        dialog.geometry("360x220")
        dialog.resizable(False, False)
        dialog.grab_set()

        ctk.CTkLabel(dialog, text="Project name", anchor="w").pack(
            fill="x", padx=20, pady=(20, 2)
        )
        name_entry = ctk.CTkEntry(dialog)
        name_entry.pack(fill="x", padx=20)
        name_entry.focus()

        ctk.CTkLabel(dialog, text="Project type", anchor="w").pack(
            fill="x", padx=20, pady=(12, 2)
        )
        type_option = ctk.CTkOptionMenu(
            dialog, values=["Video", "Image", "Audio", "Script", "General"]
        )
        type_option.pack(fill="x", padx=20)

        error_label = ctk.CTkLabel(dialog, text="", text_color="red")
        error_label.pack(fill="x", padx=20, pady=(8, 0))

        def create_project() -> None:
            name = name_entry.get().strip()
            if not name:
                error_label.configure(text="Project name is required.")
                return
            now = datetime.now().isoformat(timespec="seconds")
            db_manager.execute(
                """
                INSERT INTO projects (name, project_type, status, created_at, updated_at)
                VALUES (?, ?, 'Active', ?, ?)
                """,
                (name, type_option.get(), now, now),
            )
            db_manager.execute(
                "INSERT INTO activity_log (action, details) VALUES (?, ?)",
                ("project_created", name),
            )
            logger.info("Created new project: %s", name)
            dialog.destroy()
            self.refresh_data()

        ctk.CTkButton(dialog, text="Create Project", command=create_project).pack(
            fill="x", padx=20, pady=(16, 20)
        )
