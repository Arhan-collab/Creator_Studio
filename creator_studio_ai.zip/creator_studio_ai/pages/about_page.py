"""About page: static app information, version, and phase roadmap."""

from __future__ import annotations

import logging
import webbrowser

import customtkinter as ctk

from config.app_config import APP_NAME, APP_TAGLINE, APP_VERSION
from modules.base_page import BasePage

logger = logging.getLogger(__name__)


class AboutPage(BasePage):
    page_key = "about"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._build_ui()

    def _build_ui(self) -> None:
        container = ctk.CTkFrame(self, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=40, pady=40)

        ctk.CTkLabel(
            container, text=APP_NAME, font=ctk.CTkFont(size=28, weight="bold")
        ).pack(anchor="w")

        ctk.CTkLabel(
            container,
            text=APP_TAGLINE,
            font=ctk.CTkFont(size=14),
            text_color=("gray40", "gray65"),
        ).pack(anchor="w", pady=(2, 20))

        info_card = ctk.CTkFrame(container, corner_radius=12)
        info_card.pack(fill="x", pady=(0, 20))

        self._info_row(info_card, "Version", APP_VERSION)
        self._info_row(info_card, "Build stack", "Python 3.12 · CustomTkinter · SQLite")
        self._info_row(info_card, "Current phase", "Phase 1 - Core Application Shell")

        roadmap_label = ctk.CTkLabel(
            container,
            text="Planned phases",
            font=ctk.CTkFont(size=15, weight="bold"),
        )
        roadmap_label.pack(anchor="w", pady=(10, 6))

        roadmap_items = [
            "Phase 2 - Project Manager & Asset Manager",
            "Phase 3 - AI Writer, Script Writer & AI Provider integrations",
            "Phase 4 - Thumbnail Studio & AI Thumbnail Assistant",
            "Phase 5 - Title / Caption / Description / Hashtag generators",
            "Phase 6 - Content Calendar, Analytics & Productivity tools",
            "Phase 7 - Brand Kit, Plugin system & background services",
        ]
        for item in roadmap_items:
            ctk.CTkLabel(
                container, text=f"•  {item}", font=ctk.CTkFont(size=13), anchor="w"
            ).pack(anchor="w", pady=1)

        link_button = ctk.CTkButton(
            container,
            text="View project on GitHub",
            width=200,
            command=self._open_placeholder_link,
        )
        link_button.pack(anchor="w", pady=(24, 0))

    def _info_row(self, parent: ctk.CTkFrame, label: str, value: str) -> None:
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=6)
        ctk.CTkLabel(
            row, text=label, width=140, anchor="w", font=ctk.CTkFont(size=13, weight="bold")
        ).pack(side="left")
        ctk.CTkLabel(row, text=value, anchor="w", font=ctk.CTkFont(size=13)).pack(side="left")
        
    def _open_placeholder_link(self) -> None:
        logger.info("Opening GitHub repository.")
        webbrowser.open("https://github.com/Arhan-collab")