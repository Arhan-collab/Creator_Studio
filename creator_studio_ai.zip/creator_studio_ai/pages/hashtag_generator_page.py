"""Hashtag Generator: platform and audience-aware hashtag sets, grouped by
popularity/difficulty."""

from __future__ import annotations

import customtkinter as ctk

from config.app_config import SOCIAL_PLATFORMS
from modules.generator_page_base import GeneratorPageBase


class HashtagGeneratorPage(GeneratorPageBase):
    page_key = "hashtag_generator"
    content_type = "hashtag"
    page_title = "Hashtag Generator"
    page_subtitle = "Generate hashtags grouped by popularity for your topic and platform."

    def build_form(self, parent: ctk.CTkFrame) -> None:
        row1 = ctk.CTkFrame(parent, fg_color="transparent")
        row1.pack(fill="x", pady=4)
        ctk.CTkLabel(row1, text="Topic", width=160, anchor="w").pack(side="left")
        self._topic_entry = ctk.CTkEntry(row1, placeholder_text="e.g. home espresso brewing")
        self._topic_entry.pack(side="left", fill="x", expand=True)

        row2 = ctk.CTkFrame(parent, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Platform", width=160, anchor="w").pack(side="left")
        self._platform_menu = ctk.CTkOptionMenu(row2, values=SOCIAL_PLATFORMS)
        self._platform_menu.pack(side="left")

        row3 = ctk.CTkFrame(parent, fg_color="transparent")
        row3.pack(fill="x", pady=4)
        ctk.CTkLabel(row3, text="Target audience", width=160, anchor="w").pack(side="left")
        self._audience_entry = ctk.CTkEntry(row3, placeholder_text="e.g. home baristas, coffee beginners")
        self._audience_entry.pack(side="left", fill="x", expand=True)

    def get_topic(self) -> str:
        return self._topic_entry.get().strip()

    def get_platform(self) -> str:
        return self._platform_menu.get()

    def build_prompt(self) -> tuple[str, str]:
        topic = self.get_topic()
        if not topic:
            self.set_status("Enter a topic first.")
            return "", ""

        platform = self._platform_menu.get()
        audience = self._audience_entry.get().strip()

        system_prompt = f"You are a hashtag strategist specializing in {platform} growth."
        user_prompt = (
            f"Generate hashtags for {platform} content about: {topic}."
        )
        if audience:
            user_prompt += f" Target audience: {audience}."
        user_prompt += (
            " Group them into three sections: 'High Popularity (broad reach)', "
            "'Medium Popularity (niche)', and 'Low Popularity (easy to rank, low competition)'. "
            "List 6-10 hashtags per section."
        )
        return system_prompt, user_prompt
