"""
Project Manager.

Full CRUD over the projects table: create, edit, delete, mark favorite,
search by name/client/tags, and filter by status.
"""

from __future__ import annotations

import logging
from datetime import datetime

import customtkinter as ctk

from database.db_manager import db_manager
from modules.base_page import BasePage

logger = logging.getLogger(__name__)

_STATUS_CHOICES = ["Active", "In Progress", "Review", "Completed", "On Hold", "Archived"]
_TYPE_CHOICES = ["Video", "Image", "Audio", "Script", "General"]


class ProjectsPage(BasePage):
    page_key = "projects"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._list_frame: ctk.CTkFrame | None = None
        self._search_entry: ctk.CTkEntry | None = None
        self._status_filter: ctk.CTkOptionMenu | None = None
        self._favorites_only: ctk.BooleanVar = ctk.BooleanVar(value=False)
        self._build_ui()

    def _build_ui(self) -> None:
        header_row = ctk.CTkFrame(self, fg_color="transparent")
        header_row.pack(fill="x", padx=24, pady=(20, 8))
        ctk.CTkLabel(
            header_row, text="Projects", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        ).pack(side="left")
        ctk.CTkButton(header_row, text="+ New Project", command=self._open_project_dialog).pack(
            side="right"
        )

        filter_row = ctk.CTkFrame(self, fg_color="transparent")
        filter_row.pack(fill="x", padx=24, pady=(0, 12))

        self._search_entry = ctk.CTkEntry(filter_row, placeholder_text="Search by name, client, or tag...")
        self._search_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self._search_entry.bind("<KeyRelease>", lambda _e: self.refresh_projects())

        self._status_filter = ctk.CTkOptionMenu(
            filter_row,
            values=["All"] + _STATUS_CHOICES,
            command=lambda _v: self.refresh_projects(),
        )
        self._status_filter.pack(side="left", padx=(0, 8))

        favorites_check = ctk.CTkCheckBox(
            filter_row, text="Favorites only", variable=self._favorites_only,
            command=self.refresh_projects,
        )
        favorites_check.pack(side="left")

        self._list_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self._list_frame.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        self.refresh_projects()

    def on_show(self) -> None:
        self.refresh_projects()

    # ------------------------------------------------------------ Listing

    def refresh_projects(self) -> None:
        for widget in self._list_frame.winfo_children():
            widget.destroy()

        query = "SELECT * FROM projects WHERE 1=1"
        params: list = []

        search_term = self._search_entry.get().strip() if self._search_entry else ""
        if search_term:
            query += " AND (name LIKE ? OR client LIKE ? OR tags LIKE ?)"
            like_term = f"%{search_term}%"
            params.extend([like_term, like_term, like_term])

        status_value = self._status_filter.get() if self._status_filter else "All"
        if status_value and status_value != "All":
            query += " AND status = ?"
            params.append(status_value)

        if self._favorites_only.get():
            query += " AND is_favorite = 1"

        query += " ORDER BY updated_at DESC"
        rows = db_manager.query(query, params)

        if not rows:
            ctk.CTkLabel(
                self._list_frame, text="No projects match your filters.",
                text_color=("gray40", "gray65"),
            ).pack(anchor="w", padx=8, pady=8)
            return

        for row in rows:
            self._build_project_card(row)

    def _build_project_card(self, row) -> None:
        card = ctk.CTkFrame(self._list_frame, corner_radius=10)
        card.pack(fill="x", pady=5, padx=4)

        top_row = ctk.CTkFrame(card, fg_color="transparent")
        top_row.pack(fill="x", padx=14, pady=(12, 4))

        star = "\u2605" if row["is_favorite"] else "\u2606"
        title_text = f"{star}  {row['name']}"
        ctk.CTkLabel(
            top_row, text=title_text, font=ctk.CTkFont(size=15, weight="bold"), anchor="w"
        ).pack(side="left")

        ctk.CTkLabel(
            top_row, text=row["status"], fg_color=("gray80", "gray30"), corner_radius=6,
            padx=8,
        ).pack(side="right")

        detail_row = ctk.CTkFrame(card, fg_color="transparent")
        detail_row.pack(fill="x", padx=14, pady=(0, 4))
        details = f"Type: {row['project_type']}"
        if row["client"]:
            details += f"   \u2022   Client: {row['client']}"
        if row["deadline"]:
            details += f"   \u2022   Deadline: {row['deadline']}"
        ctk.CTkLabel(
            detail_row, text=details, anchor="w", text_color=("gray35", "gray65"), font=ctk.CTkFont(size=12)
        ).pack(side="left")

        if row["tags"]:
            tags_row = ctk.CTkFrame(card, fg_color="transparent")
            tags_row.pack(fill="x", padx=14, pady=(0, 4))
            ctk.CTkLabel(
                tags_row, text=f"Tags: {row['tags']}", anchor="w", font=ctk.CTkFont(size=11),
                text_color=("gray45", "gray55"),
            ).pack(side="left")

        button_row = ctk.CTkFrame(card, fg_color="transparent")
        button_row.pack(fill="x", padx=14, pady=(4, 12))

        ctk.CTkButton(
            button_row, text=("Unfavorite" if row["is_favorite"] else "Favorite"), width=90,
            height=26, command=lambda pid=row["id"], fav=row["is_favorite"]: self._toggle_favorite(pid, fav),
        ).pack(side="left", padx=(0, 6))
        ctk.CTkButton(
            button_row, text="Edit", width=70, height=26,
            command=lambda pid=row["id"]: self._open_project_dialog(project_id=pid),
        ).pack(side="left", padx=(0, 6))
        ctk.CTkButton(
            button_row, text="Delete", width=70, height=26, fg_color="darkred",
            command=lambda pid=row["id"]: self._delete_project(pid),
        ).pack(side="left")

    # -------------------------------------------------------------- Actions

    def _toggle_favorite(self, project_id: int, currently_favorite: int) -> None:
        db_manager.execute(
            "UPDATE projects SET is_favorite = ?, updated_at = ? WHERE id = ?",
            (0 if currently_favorite else 1, datetime.now().isoformat(timespec="seconds"), project_id),
        )
        self.refresh_projects()

    def _delete_project(self, project_id: int) -> None:
        db_manager.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        db_manager.execute(
            "INSERT INTO activity_log (action, details) VALUES ('project_deleted', ?)",
            (str(project_id),),
        )
        self.refresh_projects()

    def _open_project_dialog(self, project_id: int | None = None) -> None:
        existing = None
        if project_id is not None:
            existing = db_manager.query_one("SELECT * FROM projects WHERE id = ?", (project_id,))

        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Project" if existing else "New Project")
        dialog.geometry("420x480")
        dialog.resizable(False, False)
        dialog.grab_set()

        def labeled_entry(label: str, initial: str = "") -> ctk.CTkEntry:
            ctk.CTkLabel(dialog, text=label, anchor="w").pack(fill="x", padx=20, pady=(10, 2))
            entry = ctk.CTkEntry(dialog)
            entry.insert(0, initial)
            entry.pack(fill="x", padx=20)
            return entry

        name_entry = labeled_entry("Project name", existing["name"] if existing else "")

        ctk.CTkLabel(dialog, text="Project type", anchor="w").pack(fill="x", padx=20, pady=(10, 2))
        type_menu = ctk.CTkOptionMenu(dialog, values=_TYPE_CHOICES)
        type_menu.set(existing["project_type"] if existing else _TYPE_CHOICES[0])
        type_menu.pack(fill="x", padx=20)

        ctk.CTkLabel(dialog, text="Status", anchor="w").pack(fill="x", padx=20, pady=(10, 2))
        status_menu = ctk.CTkOptionMenu(dialog, values=_STATUS_CHOICES)
        status_menu.set(existing["status"] if existing else _STATUS_CHOICES[0])
        status_menu.pack(fill="x", padx=20)

        client_entry = labeled_entry("Client (optional)", existing["client"] if existing else "")
        deadline_entry = labeled_entry(
            "Deadline YYYY-MM-DD (optional)", existing["deadline"] if existing and existing["deadline"] else ""
        )
        tags_entry = labeled_entry(
            "Tags, comma separated (optional)", existing["tags"] if existing else ""
        )

        error_label = ctk.CTkLabel(dialog, text="", text_color="red")
        error_label.pack(fill="x", padx=20, pady=(6, 0))

        def save() -> None:
            name = name_entry.get().strip()
            if not name:
                error_label.configure(text="Project name is required.")
                return
            now = datetime.now().isoformat(timespec="seconds")
            deadline_value = deadline_entry.get().strip() or None

            if existing:
                db_manager.execute(
                    """
                    UPDATE projects
                    SET name = ?, project_type = ?, status = ?, client = ?, deadline = ?, tags = ?, updated_at = ?
                    WHERE id = ?
                    """,
                    (
                        name, type_menu.get(), status_menu.get(), client_entry.get().strip(),
                        deadline_value, tags_entry.get().strip(), now, existing["id"],
                    ),
                )
            else:
                db_manager.execute(
                    """
                    INSERT INTO projects (name, project_type, status, client, deadline, tags, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        name, type_menu.get(), status_menu.get(), client_entry.get().strip(),
                        deadline_value, tags_entry.get().strip(), now, now,
                    ),
                )
            dialog.destroy()
            self.refresh_projects()

        ctk.CTkButton(dialog, text="Save Project", command=save).pack(fill="x", padx=20, pady=(16, 20))
