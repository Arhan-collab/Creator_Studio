"""
Asset Manager.

Imports references to real files on disk (videos, images, audio, fonts,
templates, logos), stores them with tags/type/favorite in the assets table,
and provides fast search plus image thumbnail previews via Pillow.
"""

from __future__ import annotations

import logging
from pathlib import Path
from tkinter import filedialog

import customtkinter as ctk
from PIL import Image

from config.app_config import ASSET_TYPES
from database.db_manager import db_manager
from modules.base_page import BasePage

logger = logging.getLogger(__name__)

_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
_VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm"}
_AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".aac", ".m4a"}
_FONT_EXTENSIONS = {".ttf", ".otf"}


def _guess_asset_type(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in _IMAGE_EXTENSIONS:
        return "Image"
    if suffix in _VIDEO_EXTENSIONS:
        return "Video"
    if suffix in _AUDIO_EXTENSIONS:
        return "Audio"
    if suffix in _FONT_EXTENSIONS:
        return "Font"
    return "Other"


class AssetManagerPage(BasePage):
    page_key = "asset_manager"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._grid_frame: ctk.CTkFrame | None = None
        self._search_entry: ctk.CTkEntry | None = None
        self._type_filter: ctk.CTkOptionMenu | None = None
        self._thumbnail_cache: dict[int, ctk.CTkImage] = {}
        self._build_ui()

    def _build_ui(self) -> None:
        header_row = ctk.CTkFrame(self, fg_color="transparent")
        header_row.pack(fill="x", padx=24, pady=(20, 8))
        ctk.CTkLabel(
            header_row, text="Asset Manager", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        ).pack(side="left")
        ctk.CTkButton(header_row, text="+ Import Assets", command=self._import_assets).pack(side="right")

        filter_row = ctk.CTkFrame(self, fg_color="transparent")
        filter_row.pack(fill="x", padx=24, pady=(0, 12))

        self._search_entry = ctk.CTkEntry(filter_row, placeholder_text="Search by name or tag...")
        self._search_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self._search_entry.bind("<KeyRelease>", lambda _e: self.refresh_assets())

        self._type_filter = ctk.CTkOptionMenu(
            filter_row, values=["All"] + ASSET_TYPES, command=lambda _v: self.refresh_assets()
        )
        self._type_filter.pack(side="left")

        self._grid_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self._grid_frame.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        self.refresh_assets()

    def on_show(self) -> None:
        self.refresh_assets()

    # ------------------------------------------------------------ Import

    def _import_assets(self) -> None:
        file_paths = filedialog.askopenfilenames(title="Select asset files")
        if not file_paths:
            return
        for raw_path in file_paths:
            path = Path(raw_path)
            db_manager.execute(
                "INSERT INTO assets (name, file_path, asset_type) VALUES (?, ?, ?)",
                (path.name, str(path), _guess_asset_type(path)),
            )
        self.refresh_assets()

    # ------------------------------------------------------------ Listing

    def refresh_assets(self) -> None:
        for widget in self._grid_frame.winfo_children():
            widget.destroy()

        query = "SELECT * FROM assets WHERE 1=1"
        params: list = []

        search_term = self._search_entry.get().strip() if self._search_entry else ""
        if search_term:
            query += " AND (name LIKE ? OR tags LIKE ?)"
            like_term = f"%{search_term}%"
            params.extend([like_term, like_term])

        type_value = self._type_filter.get() if self._type_filter else "All"
        if type_value and type_value != "All":
            query += " AND asset_type = ?"
            params.append(type_value)

        query += " ORDER BY created_at DESC"
        rows = db_manager.query(query, params)

        if not rows:
            ctk.CTkLabel(
                self._grid_frame, text="No assets yet. Import some to get started.",
                text_color=("gray40", "gray65"),
            ).pack(anchor="w", padx=8, pady=8)
            return

        columns = 3
        for index, row in enumerate(rows):
            card = self._build_asset_card(row)
            card.grid(row=index // columns, column=index % columns, sticky="nsew", padx=6, pady=6)
        for col in range(columns):
            self._grid_frame.grid_columnconfigure(col, weight=1, uniform="asset_col")

    def _build_asset_card(self, row) -> ctk.CTkFrame:
        card = ctk.CTkFrame(self._grid_frame, corner_radius=10)

        preview = self._get_preview_image(row)
        if preview is not None:
            ctk.CTkLabel(card, image=preview, text="").pack(pady=(10, 4))
        else:
            icon = {"Video": "🎬", "Audio": "🎵", "Font": "🔤", "Other": "📄"}.get(row["asset_type"], "📄")
            ctk.CTkLabel(card, text=icon, font=ctk.CTkFont(size=36)).pack(pady=(10, 4))

        ctk.CTkLabel(
            card, text=row["name"], wraplength=180, font=ctk.CTkFont(size=12, weight="bold")
        ).pack(padx=8)
        ctk.CTkLabel(
            card, text=row["asset_type"], font=ctk.CTkFont(size=10), text_color=("gray40", "gray65")
        ).pack()

        button_row = ctk.CTkFrame(card, fg_color="transparent")
        button_row.pack(pady=(6, 10))
        ctk.CTkButton(
            button_row, text="Tag", width=60, height=24,
            command=lambda asset_id=row["id"], current=row["tags"]: self._edit_tags(asset_id, current),
        ).pack(side="left", padx=(0, 4))
        ctk.CTkButton(
            button_row, text="Remove", width=70, height=24, fg_color="darkred",
            command=lambda asset_id=row["id"]: self._remove_asset(asset_id),
        ).pack(side="left")

        return card

    def _get_preview_image(self, row) -> ctk.CTkImage | None:
        if row["asset_type"] != "Image":
            return None
        if row["id"] in self._thumbnail_cache:
            return self._thumbnail_cache[row["id"]]
        path = Path(row["file_path"])
        if not path.exists():
            return None
        try:
            with Image.open(path) as img:
                img = img.convert("RGB")
                img.thumbnail((160, 160))
                ctk_image = ctk.CTkImage(light_image=img, dark_image=img, size=img.size)
                self._thumbnail_cache[row["id"]] = ctk_image
                return ctk_image
        except Exception as exc:
            logger.warning("Could not load thumbnail for %s: %s", path, exc)
            return None

    # -------------------------------------------------------------- Actions

    def _remove_asset(self, asset_id: int) -> None:
        db_manager.execute("DELETE FROM assets WHERE id = ?", (asset_id,))
        self._thumbnail_cache.pop(asset_id, None)
        self.refresh_assets()

    def _edit_tags(self, asset_id: int, current_tags: str) -> None:
        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Tags")
        dialog.geometry("340x160")
        dialog.resizable(False, False)
        dialog.grab_set()

        ctk.CTkLabel(dialog, text="Tags, comma separated", anchor="w").pack(fill="x", padx=20, pady=(20, 4))
        entry = ctk.CTkEntry(dialog)
        entry.insert(0, current_tags or "")
        entry.pack(fill="x", padx=20)

        def save() -> None:
            db_manager.execute("UPDATE assets SET tags = ? WHERE id = ?", (entry.get().strip(), asset_id))
            dialog.destroy()
            self.refresh_assets()

        ctk.CTkButton(dialog, text="Save", command=save).pack(fill="x", padx=20, pady=20)
