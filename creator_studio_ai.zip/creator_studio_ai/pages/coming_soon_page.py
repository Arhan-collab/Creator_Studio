"""
Shown for any sidebar section not yet implemented in the current build
phase. This is an intentional, clearly-labeled placeholder shared by every
unbuilt section - not a fake implementation of any specific feature.
"""

from __future__ import annotations

import customtkinter as ctk

from modules.base_page import BasePage


class ComingSoonPage(BasePage):
    page_key = "coming_soon"

    def __init__(self, master: ctk.CTkBaseClass, section_label: str, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._section_label = section_label
        self._build_ui()

    def _build_ui(self) -> None:
        container = ctk.CTkFrame(self, fg_color="transparent")
        container.place(relx=0.5, rely=0.45, anchor="center")

        icon_label = ctk.CTkLabel(container, text="🚧", font=ctk.CTkFont(size=48))
        icon_label.pack(pady=(0, 12))

        title_label = ctk.CTkLabel(
            container,
            text=f"{self._section_label} is coming in a future phase",
            font=ctk.CTkFont(size=18, weight="bold"),
        )
        title_label.pack()

        subtitle_label = ctk.CTkLabel(
            container,
            text=(
                "This app is being built incrementally, phase by phase.\n"
                "Dashboard, Settings, and About are fully functional today."
            ),
            font=ctk.CTkFont(size=13),
            text_color=("gray40", "gray65"),
            justify="center",
        )
        subtitle_label.pack(pady=(8, 0))

    def set_section_label(self, section_label: str) -> None:
        self._section_label = section_label
        for widget in self.winfo_children():
            widget.destroy()
        self._build_ui()
