"""
Thumbnail Studio.

A layer-based thumbnail editor. The full-resolution composite is always
built with Pillow (background -> shapes/images/text in stacking order) and
then downscaled for on-screen preview, so what you export is exactly what
you see. Dragging on the preview canvas moves the topmost layer under the
cursor; the property panel edits whatever layer is currently selected.
"""

from __future__ import annotations

import logging
from pathlib import Path
from tkinter import colorchooser, filedialog

import customtkinter as ctk
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from modules.base_page import BasePage

logger = logging.getLogger(__name__)

CANVAS_WIDTH = 1280
CANVAS_HEIGHT = 720
PREVIEW_SCALE = 0.5
PREVIEW_WIDTH = int(CANVAS_WIDTH * PREVIEW_SCALE)
PREVIEW_HEIGHT = int(CANVAS_HEIGHT * PREVIEW_SCALE)


def _load_font(size: int, bold: bool) -> ImageFont.FreeTypeFont:
    candidates = (
        ["arialbd.ttf", "DejaVuSans-Bold.ttf"] if bold else ["arial.ttf", "DejaVuSans.ttf"]
    )
    for name in candidates:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


class ThumbnailStudioPage(BasePage):
    page_key = "thumbnail_studio"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._layers: list[dict] = []
        self._next_layer_id = 1
        self._selected_layer_id: int | None = None
        self._background_color = "#1e1e2e"
        self._background_image_path: str | None = None
        self._dragging_layer_id: int | None = None
        self._drag_offset = (0, 0)
        self._preview_photo: ctk.CTkImage | None = None
        self._property_panel: ctk.CTkFrame | None = None
        self._layer_list_frame: ctk.CTkFrame | None = None
        self._canvas_label: ctk.CTkLabel | None = None
        self._build_ui()
        self.render()

    # ------------------------------------------------------------------ UI

    def _build_ui(self) -> None:
        header = ctk.CTkLabel(
            self, text="Thumbnail Studio", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 8))

        toolbar = ctk.CTkFrame(self, fg_color="transparent")
        toolbar.pack(fill="x", padx=24, pady=(0, 10))
        ctk.CTkButton(toolbar, text="+ Text", width=90, command=self._add_text_layer).pack(side="left", padx=3)
        ctk.CTkButton(toolbar, text="+ Rectangle", width=100, command=lambda: self._add_shape_layer("rectangle")).pack(
            side="left", padx=3
        )
        ctk.CTkButton(toolbar, text="+ Ellipse", width=90, command=lambda: self._add_shape_layer("ellipse")).pack(
            side="left", padx=3
        )
        ctk.CTkButton(toolbar, text="+ Image", width=90, command=self._add_image_layer).pack(side="left", padx=3)
        ctk.CTkButton(toolbar, text="Background Color", width=130, command=self._pick_background_color).pack(
            side="left", padx=3
        )
        ctk.CTkButton(toolbar, text="Background Image", width=130, command=self._pick_background_image).pack(
            side="left", padx=3
        )
        ctk.CTkButton(toolbar, text="Export PNG", width=100, command=lambda: self._export("PNG")).pack(
            side="right", padx=3
        )
        ctk.CTkButton(toolbar, text="Export JPG", width=100, command=lambda: self._export("JPEG")).pack(
            side="right", padx=3
        )
        ctk.CTkButton(
            toolbar, text="\u2728 AI Suggestions", width=140, command=self._open_ai_assistant_dialog
        ).pack(side="right", padx=3)

        main_row = ctk.CTkFrame(self, fg_color="transparent")
        main_row.pack(fill="both", expand=True, padx=24, pady=(0, 20))
        main_row.grid_columnconfigure(0, weight=3)
        main_row.grid_columnconfigure(1, weight=1)
        main_row.grid_rowconfigure(0, weight=1)

        canvas_card = ctk.CTkFrame(main_row, corner_radius=12)
        canvas_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self._canvas_label = ctk.CTkLabel(canvas_card, text="")
        self._canvas_label.pack(expand=True, padx=10, pady=10)
        self._canvas_label.bind("<Button-1>", self._on_canvas_press)
        self._canvas_label.bind("<B1-Motion>", self._on_canvas_drag)
        self._canvas_label.bind("<ButtonRelease-1>", self._on_canvas_release)

        side_panel = ctk.CTkFrame(main_row, fg_color="transparent")
        side_panel.grid(row=0, column=1, sticky="nsew")

        layers_card = ctk.CTkFrame(side_panel, corner_radius=12)
        layers_card.pack(fill="both", expand=True, pady=(0, 10))
        ctk.CTkLabel(layers_card, text="Layers", font=ctk.CTkFont(size=14, weight="bold")).pack(
            anchor="w", padx=14, pady=(12, 4)
        )
        self._layer_list_frame = ctk.CTkFrame(layers_card, fg_color="transparent")
        self._layer_list_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        properties_card = ctk.CTkFrame(side_panel, corner_radius=12)
        properties_card.pack(fill="both", expand=True)
        ctk.CTkLabel(properties_card, text="Properties", font=ctk.CTkFont(size=14, weight="bold")).pack(
            anchor="w", padx=14, pady=(12, 4)
        )
        self._property_panel = ctk.CTkFrame(properties_card, fg_color="transparent")
        self._property_panel.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    # -------------------------------------------------------------- Layers

    def _add_text_layer(self) -> None:
        layer_id = self._next_layer_id
        self._next_layer_id += 1
        self._layers.append(
            {
                "id": layer_id,
                "kind": "text",
                "x": 100,
                "y": 100,
                "w": 500,
                "h": 120,
                "rotation": 0,
                "text": "Your Text Here",
                "font_size": 64,
                "color": "#ffffff",
                "bold": True,
                "shadow": True,
            }
        )
        self._select_layer(layer_id)

    def _add_shape_layer(self, shape_type: str) -> None:
        layer_id = self._next_layer_id
        self._next_layer_id += 1
        self._layers.append(
            {
                "id": layer_id,
                "kind": "shape",
                "shape_type": shape_type,
                "x": 150,
                "y": 150,
                "w": 300,
                "h": 180,
                "rotation": 0,
                "color": "#3b82f6",
            }
        )
        self._select_layer(layer_id)

    def _add_image_layer(self) -> None:
        file_path = filedialog.askopenfilename(
            title="Select image", filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.webp")]
        )
        if not file_path:
            return
        layer_id = self._next_layer_id
        self._next_layer_id += 1
        try:
            with Image.open(file_path) as img:
                width, height = img.size
        except Exception as exc:
            logger.error("Could not open image %s: %s", file_path, exc)
            return
        max_dim = 400
        scale = min(max_dim / width, max_dim / height, 1.0)
        self._layers.append(
            {
                "id": layer_id,
                "kind": "image",
                "path": file_path,
                "x": 200,
                "y": 200,
                "w": int(width * scale),
                "h": int(height * scale),
                "rotation": 0,
                "remove_background": False,
            }
        )
        self._select_layer(layer_id)

    def _pick_background_color(self) -> None:
        color = colorchooser.askcolor(color=self._background_color, title="Background color")
        if color and color[1]:
            self._background_color = color[1]
            self._background_image_path = None
            self.render()

    def _pick_background_image(self) -> None:
        file_path = filedialog.askopenfilename(
            title="Select background image", filetypes=[("Images", "*.png *.jpg *.jpeg *.bmp *.webp")]
        )
        if file_path:
            self._background_image_path = file_path
            self.render()

    def _select_layer(self, layer_id: int | None) -> None:
        self._selected_layer_id = layer_id
        self._refresh_layer_list()
        self._refresh_property_panel()
        self.render()

    def _get_layer(self, layer_id: int) -> dict | None:
        return next((l for l in self._layers if l["id"] == layer_id), None)

    def _delete_layer(self, layer_id: int) -> None:
        self._layers = [l for l in self._layers if l["id"] != layer_id]
        if self._selected_layer_id == layer_id:
            self._selected_layer_id = None
        self._select_layer(self._selected_layer_id)

    def _move_layer(self, layer_id: int, direction: int) -> None:
        index = next((i for i, l in enumerate(self._layers) if l["id"] == layer_id), None)
        if index is None:
            return
        new_index = index + direction
        if 0 <= new_index < len(self._layers):
            self._layers[index], self._layers[new_index] = self._layers[new_index], self._layers[index]
            self._select_layer(layer_id)

    # --------------------------------------------------------- Layer panel

    def _refresh_layer_list(self) -> None:
        for widget in self._layer_list_frame.winfo_children():
            widget.destroy()

        if not self._layers:
            ctk.CTkLabel(
                self._layer_list_frame, text="No layers yet.", text_color=("gray40", "gray65")
            ).pack(anchor="w")
            return

        for layer in reversed(self._layers):
            label = {"text": "T  ", "shape": "\u25a1  ", "image": "\U0001F5BC  "}.get(layer["kind"], "")
            if layer["kind"] == "text":
                label += layer["text"][:16]
            elif layer["kind"] == "shape":
                label += layer["shape_type"].title()
            else:
                label += Path(layer["path"]).name[:16]

            is_selected = layer["id"] == self._selected_layer_id
            row = ctk.CTkFrame(
                self._layer_list_frame, fg_color=("gray80", "gray30") if is_selected else "transparent"
            )
            row.pack(fill="x", pady=2)
            ctk.CTkButton(
                row, text=label, anchor="w", fg_color="transparent", hover_color=("gray85", "gray25"),
                command=lambda lid=layer["id"]: self._select_layer(lid),
            ).pack(side="left", fill="x", expand=True)
            ctk.CTkButton(
                row, text="\u2191", width=26, command=lambda lid=layer["id"]: self._move_layer(lid, 1)
            ).pack(side="left")
            ctk.CTkButton(
                row, text="\u2193", width=26, command=lambda lid=layer["id"]: self._move_layer(lid, -1)
            ).pack(side="left")
            ctk.CTkButton(
                row, text="\u2715", width=26, fg_color="darkred",
                command=lambda lid=layer["id"]: self._delete_layer(lid),
            ).pack(side="left")

    # ------------------------------------------------------ Property panel

    def _refresh_property_panel(self) -> None:
        for widget in self._property_panel.winfo_children():
            widget.destroy()

        if self._selected_layer_id is None:
            ctk.CTkLabel(
                self._property_panel, text="Select a layer to edit its properties.",
                text_color=("gray40", "gray65"), wraplength=220, justify="left",
            ).pack(anchor="w")
            return

        layer = self._get_layer(self._selected_layer_id)
        if layer is None:
            return

        def numeric_row(label: str, key: str) -> None:
            row = ctk.CTkFrame(self._property_panel, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkLabel(row, text=label, width=70, anchor="w").pack(side="left")
            entry = ctk.CTkEntry(row, width=80)
            entry.insert(0, str(layer[key]))
            entry.pack(side="left")

            def commit(_event=None, k=key, e=entry) -> None:
                try:
                    layer[k] = int(float(e.get()))
                except ValueError:
                    pass
                self.render()

            entry.bind("<Return>", commit)
            entry.bind("<FocusOut>", commit)

        numeric_row("X", "x")
        numeric_row("Y", "y")
        numeric_row("Width", "w")
        numeric_row("Height", "h")
        numeric_row("Rotation", "rotation")

        if layer["kind"] == "text":
            ctk.CTkLabel(self._property_panel, text="Text", anchor="w").pack(fill="x", pady=(8, 2))
            text_entry = ctk.CTkEntry(self._property_panel)
            text_entry.insert(0, layer["text"])
            text_entry.pack(fill="x")

            def commit_text(_event=None) -> None:
                layer["text"] = text_entry.get()
                self.render()

            text_entry.bind("<Return>", commit_text)
            text_entry.bind("<FocusOut>", commit_text)

            numeric_row("Font size", "font_size")

            ctk.CTkButton(
                self._property_panel, text="Text Color", command=lambda: self._pick_layer_color(layer, "color")
            ).pack(fill="x", pady=(6, 2))

            bold_var = ctk.BooleanVar(value=layer["bold"])
            shadow_var = ctk.BooleanVar(value=layer["shadow"])

            def commit_bold() -> None:
                layer["bold"] = bold_var.get()
                self.render()

            def commit_shadow() -> None:
                layer["shadow"] = shadow_var.get()
                self.render()

            ctk.CTkCheckBox(self._property_panel, text="Bold", variable=bold_var, command=commit_bold).pack(
                anchor="w", pady=2
            )
            ctk.CTkCheckBox(
                self._property_panel, text="Drop shadow", variable=shadow_var, command=commit_shadow
            ).pack(anchor="w", pady=2)

        elif layer["kind"] == "shape":
            ctk.CTkButton(
                self._property_panel, text="Fill Color", command=lambda: self._pick_layer_color(layer, "color")
            ).pack(fill="x", pady=(8, 2))

        elif layer["kind"] == "image":
            remove_bg_var = ctk.BooleanVar(value=layer["remove_background"])

            def commit_remove_bg() -> None:
                layer["remove_background"] = remove_bg_var.get()
                self.render()

            ctk.CTkCheckBox(
                self._property_panel, text="Remove solid background", variable=remove_bg_var,
                command=commit_remove_bg,
            ).pack(anchor="w", pady=(8, 2))

    def _pick_layer_color(self, layer: dict, key: str) -> None:
        color = colorchooser.askcolor(color=layer.get(key, "#ffffff"), title="Choose color")
        if color and color[1]:
            layer[key] = color[1]
            self.render()

    # -------------------------------------------------------------- Render

    def _render_layer_tile(self, layer: dict) -> Image.Image | None:
        width = max(int(layer["w"]), 1)
        height = max(int(layer["h"]), 1)

        if layer["kind"] == "shape":
            tile = Image.new("RGBA", (width, height), (0, 0, 0, 0))
            draw = ImageDraw.Draw(tile)
            if layer["shape_type"] == "rectangle":
                draw.rectangle([0, 0, width - 1, height - 1], fill=layer["color"])
            else:
                draw.ellipse([0, 0, width - 1, height - 1], fill=layer["color"])
            return tile

        if layer["kind"] == "text":
            tile = Image.new("RGBA", (width, height), (0, 0, 0, 0))
            font = _load_font(layer["font_size"], layer["bold"])
            draw = ImageDraw.Draw(tile)
            if layer["shadow"]:
                draw.text((4, 4), layer["text"], font=font, fill=(0, 0, 0, 160))
            draw.text((0, 0), layer["text"], font=font, fill=layer["color"])
            return tile

        if layer["kind"] == "image":
            path = Path(layer["path"])
            if not path.exists():
                return None
            with Image.open(path) as img:
                img = img.convert("RGBA").resize((width, height), Image.LANCZOS)
                if layer["remove_background"]:
                    img = self._remove_solid_background(img)
                return img

        return None

    @staticmethod
    def _remove_solid_background(img: Image.Image, tolerance: int = 30) -> Image.Image:
        """Basic color-key background removal: samples the corner pixel and
        makes closely-matching pixels transparent. Works well for images
        with a flat solid background; not a substitute for ML-based
        segmentation, but a real, functioning transformation."""
        img = img.convert("RGBA")
        key_color = img.getpixel((0, 0))
        pixels = img.load()
        width, height = img.size
        for y in range(height):
            for x in range(width):
                r, g, b, a = pixels[x, y]
                if (
                    abs(r - key_color[0]) <= tolerance
                    and abs(g - key_color[1]) <= tolerance
                    and abs(b - key_color[2]) <= tolerance
                ):
                    pixels[x, y] = (r, g, b, 0)
        return img

    def render(self) -> None:
        if self._background_image_path and Path(self._background_image_path).exists():
            with Image.open(self._background_image_path) as bg:
                composite = bg.convert("RGBA").resize((CANVAS_WIDTH, CANVAS_HEIGHT), Image.LANCZOS)
        else:
            composite = Image.new("RGBA", (CANVAS_WIDTH, CANVAS_HEIGHT), self._background_color)

        for layer in self._layers:
            tile = self._render_layer_tile(layer)
            if tile is None:
                continue
            rotation = layer.get("rotation", 0)
            if rotation:
                tile = tile.rotate(rotation, expand=True, resample=Image.BICUBIC)
            composite.alpha_composite(tile, (int(layer["x"]), int(layer["y"])))

        self._last_render = composite.convert("RGB")
        preview = self._last_render.resize((PREVIEW_WIDTH, PREVIEW_HEIGHT), Image.LANCZOS)
        self._preview_photo = ctk.CTkImage(light_image=preview, dark_image=preview, size=(PREVIEW_WIDTH, PREVIEW_HEIGHT))
        if self._canvas_label is not None:
            self._canvas_label.configure(image=self._preview_photo, text="")

    # ------------------------------------------------------------- Dragging

    def _canvas_to_full_res(self, event_x: int, event_y: int) -> tuple[int, int]:
        return int(event_x / PREVIEW_SCALE), int(event_y / PREVIEW_SCALE)

    def _on_canvas_press(self, event) -> None:
        full_x, full_y = self._canvas_to_full_res(event.x, event.y)
        for layer in reversed(self._layers):
            if layer["x"] <= full_x <= layer["x"] + layer["w"] and layer["y"] <= full_y <= layer["y"] + layer["h"]:
                self._dragging_layer_id = layer["id"]
                self._drag_offset = (full_x - layer["x"], full_y - layer["y"])
                self._select_layer(layer["id"])
                return
        self._select_layer(None)

    def _on_canvas_drag(self, event) -> None:
        if self._dragging_layer_id is None:
            return
        layer = self._get_layer(self._dragging_layer_id)
        if layer is None:
            return
        full_x, full_y = self._canvas_to_full_res(event.x, event.y)
        layer["x"] = max(0, full_x - self._drag_offset[0])
        layer["y"] = max(0, full_y - self._drag_offset[1])
        self.render()
        if self._selected_layer_id == layer["id"]:
            self._refresh_property_panel()

    def _on_canvas_release(self, _event) -> None:
        self._dragging_layer_id = None

    # ------------------------------------------------------- AI Assistant

    def _open_ai_assistant_dialog(self) -> None:
        from services.ai.ai_provider import AIRequest, get_active_provider

        provider = get_active_provider()

        dialog = ctk.CTkToplevel(self)
        dialog.title("AI Thumbnail Assistant")
        dialog.geometry("480x480")
        dialog.grab_set()

        ctk.CTkLabel(
            dialog, text="What is this thumbnail for?", anchor="w"
        ).pack(fill="x", padx=20, pady=(20, 4))
        topic_entry = ctk.CTkEntry(dialog, placeholder_text="e.g. Tech review of a new smartphone")
        topic_entry.pack(fill="x", padx=20)

        ctk.CTkLabel(dialog, text="Current colors / style (optional)", anchor="w").pack(
            fill="x", padx=20, pady=(10, 4)
        )
        style_entry = ctk.CTkEntry(dialog, placeholder_text="e.g. dark blue background, white bold text")
        style_entry.pack(fill="x", padx=20)

        output_box = ctk.CTkTextbox(dialog, height=260, wrap="word")
        output_box.pack(fill="both", expand=True, padx=20, pady=(14, 10))

        status_label = ctk.CTkLabel(dialog, text="")
        status_label.pack(fill="x", padx=20)

        def request_suggestions() -> None:
            topic = topic_entry.get().strip()
            if not topic:
                status_label.configure(text="Describe the thumbnail's topic first.")
                return
            if not provider.is_configured():
                output_box.delete("1.0", "end")
                output_box.insert("1.0", "No AI provider configured.")
                return

            style = style_entry.get().strip()
            status_label.configure(text="Contacting AI provider...")
            generate_button.configure(state="disabled")

            def run() -> None:
                prompt = (
                    f"Suggest thumbnail design improvements for higher click-through rate for a "
                    f"video/post about: {topic}."
                )
                if style:
                    prompt += f" Current style: {style}."
                prompt += (
                    " Give specific, actionable suggestions grouped under: Colors, Layout, "
                    "Fonts, Visual Balance. Keep each group to 2-3 short bullet points."
                )
                response = provider.generate(
                    AIRequest(
                        prompt=prompt,
                        system_prompt="You are a thumbnail design expert who optimizes for click-through rate.",
                    )
                )
                self.after(0, lambda: on_done(response))

            def on_done(response) -> None:
                generate_button.configure(state="normal")
                output_box.delete("1.0", "end")
                output_box.insert("1.0", response.text if response.success else (response.error or "Failed."))
                status_label.configure(text="Done." if response.success else "Generation failed.")

            import threading

            threading.Thread(target=run, daemon=True).start()

        generate_button = ctk.CTkButton(dialog, text="Get Suggestions", command=request_suggestions)
        generate_button.pack(padx=20, pady=(0, 20), fill="x")

    # -------------------------------------------------------------- Export

    def _export(self, image_format: str) -> None:
        extension = ".png" if image_format == "PNG" else ".jpg"
        destination = filedialog.asksaveasfilename(
            defaultextension=extension,
            filetypes=[("PNG", "*.png")] if image_format == "PNG" else [("JPEG", "*.jpg *.jpeg")],
            initialfile=f"thumbnail{extension}",
        )
        if not destination:
            return
        image_to_save = self._last_render
        if image_format == "JPEG":
            image_to_save = image_to_save.convert("RGB")
        image_to_save.save(destination, image_format)
        logger.info("Thumbnail exported to %s", destination)
