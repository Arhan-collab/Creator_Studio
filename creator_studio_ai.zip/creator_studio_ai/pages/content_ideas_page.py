"""
Content Ideas.

Two parts:
1. Generate a batch of ideas from a topic/niche via the AI provider, each
   saved individually to content_ideas.
2. Browse, filter, mark-as-used, or delete ideas already in the backlog.
"""

from __future__ import annotations

import logging
import threading

import customtkinter as ctk

from database.db_manager import db_manager
from modules.base_page import BasePage
from services.ai.ai_provider import AIRequest, get_active_provider

logger = logging.getLogger(__name__)

_CATEGORY_CHOICES = [
    "General",
    "Gaming",
    "Tech",
    "Education",
    "Reviews",
    "Storytelling",
    "Marketing",
    "Lifestyle",
]


class ContentIdeasPage(BasePage):
    page_key = "content_ideas"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._ideas_list_frame: ctk.CTkFrame | None = None
        self._filter_menu: ctk.CTkOptionMenu | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        header = ctk.CTkLabel(
            self, text="Content Ideas", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 12))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=24, pady=(0, 16))

        generate_card = ctk.CTkFrame(scroll, corner_radius=12)
        generate_card.pack(fill="x", pady=(0, 12))
        gen_body = ctk.CTkFrame(generate_card, fg_color="transparent")
        gen_body.pack(fill="x", padx=18, pady=16)

        ctk.CTkLabel(gen_body, text="Generate Ideas", font=ctk.CTkFont(size=15, weight="bold")).pack(
            anchor="w"
        )

        row1 = ctk.CTkFrame(gen_body, fg_color="transparent")
        row1.pack(fill="x", pady=(10, 4))
        ctk.CTkLabel(row1, text="Niche / topic", width=140, anchor="w").pack(side="left")
        self._niche_entry = ctk.CTkEntry(row1, placeholder_text="e.g. home fitness for beginners")
        self._niche_entry.pack(side="left", fill="x", expand=True)

        row2 = ctk.CTkFrame(gen_body, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Category", width=140, anchor="w").pack(side="left")
        self._category_menu = ctk.CTkOptionMenu(row2, values=_CATEGORY_CHOICES)
        self._category_menu.pack(side="left")

        action_row = ctk.CTkFrame(gen_body, fg_color="transparent")
        action_row.pack(fill="x", pady=(10, 0))
        self._generate_button = ctk.CTkButton(
            action_row, text="Generate 10 Ideas", width=160, command=self._on_generate_clicked
        )
        self._generate_button.pack(side="left")
        self._status_label = ctk.CTkLabel(action_row, text="", text_color=("gray40", "gray65"))
        self._status_label.pack(side="left", padx=(12, 0))

        backlog_card = ctk.CTkFrame(scroll, corner_radius=12)
        backlog_card.pack(fill="both", expand=True)
        backlog_header_row = ctk.CTkFrame(backlog_card, fg_color="transparent")
        backlog_header_row.pack(fill="x", padx=18, pady=(14, 6))
        ctk.CTkLabel(
            backlog_header_row, text="Idea Backlog", font=ctk.CTkFont(size=15, weight="bold")
        ).pack(side="left")

        self._filter_menu = ctk.CTkOptionMenu(
            backlog_header_row,
            values=["All"] + _CATEGORY_CHOICES,
            command=lambda _v: self.refresh_ideas(),
        )
        self._filter_menu.pack(side="right")
        ctk.CTkLabel(backlog_header_row, text="Filter:").pack(side="right", padx=(0, 8))

        self._ideas_list_frame = ctk.CTkFrame(backlog_card, fg_color="transparent")
        self._ideas_list_frame.pack(fill="both", expand=True, padx=18, pady=(0, 14))

        self.refresh_ideas()

    def on_show(self) -> None:
        self.refresh_ideas()

    # ------------------------------------------------------------ Generate

    def _on_generate_clicked(self) -> None:
        niche = self._niche_entry.get().strip()
        if not niche:
            self._status_label.configure(text="Enter a niche or topic first.")
            return

        provider = get_active_provider()
        if not provider.is_configured():
            self._status_label.configure(text="No AI provider configured. Set one up in Settings.")
            return

        self._generate_button.configure(state="disabled", text="Generating...")
        self._status_label.configure(text="Contacting AI provider...")

        category = self._category_menu.get()
        thread = threading.Thread(
            target=self._run_generation, args=(provider, niche, category), daemon=True
        )
        thread.start()

    def _run_generation(self, provider, niche: str, category: str) -> None:
        request = AIRequest(
            prompt=(
                f"Generate 10 specific, actionable content ideas for a creator in the "
                f"'{niche}' niche. Return them as a plain numbered list, one idea title "
                f"per line with a short one-sentence description after a dash, no extra commentary."
            ),
            system_prompt="You are a creative content strategist for online creators.",
        )
        response = provider.generate(request)
        self.after(0, lambda: self._on_generation_complete(response, category))

    def _on_generation_complete(self, response, category: str) -> None:
        self._generate_button.configure(state="normal", text="Generate 10 Ideas")
        if not response.success:
            self._status_label.configure(text=response.error or "Generation failed.")
            return

        count = 0
        for line in response.text.splitlines():
            line = line.strip().lstrip("0123456789.-) ").strip()
            if not line:
                continue
            title, _, description = line.partition(" - ")
            db_manager.execute(
                "INSERT INTO content_ideas (title, description, category) VALUES (?, ?, ?)",
                (title.strip(), description.strip(), category),
            )
            count += 1

        self._status_label.configure(text=f"Added {count} ideas to your backlog.")
        self.refresh_ideas()

    # -------------------------------------------------------------- Backlog

    def refresh_ideas(self) -> None:
        if self._ideas_list_frame is None:
            return
        for widget in self._ideas_list_frame.winfo_children():
            widget.destroy()

        category_filter = self._filter_menu.get() if self._filter_menu else "All"
        if category_filter and category_filter != "All":
            rows = db_manager.query(
                "SELECT * FROM content_ideas WHERE category = ? ORDER BY is_used ASC, id DESC",
                (category_filter,),
            )
        else:
            rows = db_manager.query("SELECT * FROM content_ideas ORDER BY is_used ASC, id DESC")

        if not rows:
            ctk.CTkLabel(
                self._ideas_list_frame, text="No ideas yet. Generate some above.",
                text_color=("gray40", "gray65"),
            ).pack(anchor="w")
            return

        for row in rows:
            self._build_idea_row(row)

    def _build_idea_row(self, row) -> None:
        item = ctk.CTkFrame(self._ideas_list_frame, fg_color=("gray92", "gray17"), corner_radius=8)
        item.pack(fill="x", pady=3)

        text_frame = ctk.CTkFrame(item, fg_color="transparent")
        text_frame.pack(side="left", fill="x", expand=True, padx=10, pady=8)

        title_text = row["title"]
        if row["is_used"]:
            title_text = f"\u2713 {title_text}  (used)"

        ctk.CTkLabel(
            text_frame,
            text=title_text,
            anchor="w",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=("gray40", "gray60") if row["is_used"] else None,
        ).pack(fill="x")

        if row["description"]:
            ctk.CTkLabel(
                text_frame,
                text=row["description"],
                anchor="w",
                text_color=("gray30", "gray70"),
                font=ctk.CTkFont(size=11),
                wraplength=680,
                justify="left",
            ).pack(fill="x")

        ctk.CTkLabel(
            text_frame, text=row["category"], anchor="w", font=ctk.CTkFont(size=10),
            text_color=("gray45", "gray55"),
        ).pack(fill="x")

        button_frame = ctk.CTkFrame(item, fg_color="transparent")
        button_frame.pack(side="right", padx=10)

        toggle_label = "Mark unused" if row["is_used"] else "Mark used"
        ctk.CTkButton(
            button_frame,
            text=toggle_label,
            width=100,
            height=26,
            command=lambda idea_id=row["id"], used=row["is_used"]: self._toggle_used(idea_id, used),
        ).pack(side="left", padx=(0, 6))

        ctk.CTkButton(
            button_frame,
            text="Delete",
            width=70,
            height=26,
            fg_color="darkred",
            command=lambda idea_id=row["id"]: self._delete_idea(idea_id),
        ).pack(side="left")

    def _toggle_used(self, idea_id: int, currently_used: int) -> None:
        db_manager.execute(
            "UPDATE content_ideas SET is_used = ? WHERE id = ?", (0 if currently_used else 1, idea_id)
        )
        self.refresh_ideas()

    def _delete_idea(self, idea_id: int) -> None:
        db_manager.execute("DELETE FROM content_ideas WHERE id = ?", (idea_id,))
        self.refresh_ideas()
