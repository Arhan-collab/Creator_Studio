"""
Productivity.

A tabbed workspace bundling the small daily-use tools: Notes, Checklist,
Bookmarks, Clipboard History (polls the real system clipboard while this
page is visible), a working Pomodoro Timer, and Quick Snippets.
"""

from __future__ import annotations

import logging
import webbrowser
from datetime import datetime

import customtkinter as ctk

from database.db_manager import db_manager
from modules.base_page import BasePage

logger = logging.getLogger(__name__)

_POMODORO_WORK_SECONDS = 25 * 60
_POMODORO_BREAK_SECONDS = 5 * 60
_CLIPBOARD_POLL_MS = 1500


class ProductivityPage(BasePage):
    page_key = "productivity"

    def __init__(self, master: ctk.CTkBaseClass, **kwargs) -> None:
        super().__init__(master, **kwargs)
        self._last_clipboard_content: str | None = None
        self._clipboard_poll_job: str | None = None
        self._pomodoro_remaining = _POMODORO_WORK_SECONDS
        self._pomodoro_running = False
        self._pomodoro_on_break = False
        self._pomodoro_job: str | None = None

        header = ctk.CTkLabel(
            self, text="Productivity", font=ctk.CTkFont(size=24, weight="bold"), anchor="w"
        )
        header.pack(fill="x", padx=24, pady=(20, 8))

        self._tabview = ctk.CTkTabview(self)
        self._tabview.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        for tab_name in ["Notes", "Checklist", "Bookmarks", "Clipboard History", "Pomodoro Timer", "Snippets"]:
            self._tabview.add(tab_name)

        self._build_notes_tab(self._tabview.tab("Notes"))
        self._build_checklist_tab(self._tabview.tab("Checklist"))
        self._build_bookmarks_tab(self._tabview.tab("Bookmarks"))
        self._build_clipboard_tab(self._tabview.tab("Clipboard History"))
        self._build_pomodoro_tab(self._tabview.tab("Pomodoro Timer"))
        self._build_snippets_tab(self._tabview.tab("Snippets"))

    def on_show(self) -> None:
        self.refresh_notes()
        self.refresh_checklist()
        self.refresh_bookmarks()
        self.refresh_clipboard()
        self.refresh_snippets()
        self._start_clipboard_polling()

    def on_hide(self) -> None:
        self._stop_clipboard_polling()

    def on_app_close(self) -> None:
        self._stop_clipboard_polling()
        if self._pomodoro_job is not None:
            self.after_cancel(self._pomodoro_job)

    # ----------------------------------------------------------------- Notes

    def _build_notes_tab(self, tab: ctk.CTkFrame) -> None:
        top_row = ctk.CTkFrame(tab, fg_color="transparent")
        top_row.pack(fill="x", padx=12, pady=(12, 6))
        ctk.CTkButton(top_row, text="+ New Note", command=self._new_note_dialog).pack(side="left")

        self._notes_frame = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        self._notes_frame.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.refresh_notes()

    def refresh_notes(self) -> None:
        for widget in self._notes_frame.winfo_children():
            widget.destroy()
        rows = db_manager.query("SELECT * FROM notes ORDER BY updated_at DESC")
        if not rows:
            ctk.CTkLabel(self._notes_frame, text="No notes yet.", text_color=("gray40", "gray65")).pack(
                anchor="w"
            )
            return
        for row in rows:
            item = ctk.CTkFrame(self._notes_frame, fg_color=("gray92", "gray17"), corner_radius=8)
            item.pack(fill="x", pady=3)
            ctk.CTkLabel(
                item, text=row["title"], font=ctk.CTkFont(size=13, weight="bold"), anchor="w"
            ).pack(fill="x", padx=10, pady=(8, 0))
            preview = row["content"][:150].replace("\n", " ")
            ctk.CTkLabel(
                item, text=preview, anchor="w", wraplength=700, justify="left",
                text_color=("gray30", "gray70"), font=ctk.CTkFont(size=11),
            ).pack(fill="x", padx=10, pady=(2, 6))
            button_row = ctk.CTkFrame(item, fg_color="transparent")
            button_row.pack(fill="x", padx=10, pady=(0, 8))
            ctk.CTkButton(
                button_row, text="Edit", width=60, height=24,
                command=lambda r=row: self._new_note_dialog(existing=r),
            ).pack(side="left", padx=(0, 6))
            ctk.CTkButton(
                button_row, text="Delete", width=60, height=24, fg_color="darkred",
                command=lambda nid=row["id"]: self._delete_note(nid),
            ).pack(side="left")

    def _new_note_dialog(self, existing=None) -> None:
        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Note" if existing else "New Note")
        dialog.geometry("420x400")
        dialog.grab_set()

        ctk.CTkLabel(dialog, text="Title", anchor="w").pack(fill="x", padx=20, pady=(20, 2))
        title_entry = ctk.CTkEntry(dialog)
        title_entry.insert(0, existing["title"] if existing else "")
        title_entry.pack(fill="x", padx=20)

        ctk.CTkLabel(dialog, text="Content", anchor="w").pack(fill="x", padx=20, pady=(10, 2))
        content_box = ctk.CTkTextbox(dialog, height=220)
        content_box.insert("1.0", existing["content"] if existing else "")
        content_box.pack(fill="both", expand=True, padx=20)

        def save() -> None:
            title = title_entry.get().strip() or "Untitled"
            content = content_box.get("1.0", "end").strip()
            now = datetime.now().isoformat(timespec="seconds")
            if existing:
                db_manager.execute(
                    "UPDATE notes SET title = ?, content = ?, updated_at = ? WHERE id = ?",
                    (title, content, now, existing["id"]),
                )
            else:
                db_manager.execute(
                    "INSERT INTO notes (title, content, created_at, updated_at) VALUES (?, ?, ?, ?)",
                    (title, content, now, now),
                )
            dialog.destroy()
            self.refresh_notes()

        ctk.CTkButton(dialog, text="Save", command=save).pack(fill="x", padx=20, pady=(10, 20))

    def _delete_note(self, note_id: int) -> None:
        db_manager.execute("DELETE FROM notes WHERE id = ?", (note_id,))
        self.refresh_notes()

    # ------------------------------------------------------------- Checklist

    def _build_checklist_tab(self, tab: ctk.CTkFrame) -> None:
        add_row = ctk.CTkFrame(tab, fg_color="transparent")
        add_row.pack(fill="x", padx=12, pady=(12, 6))
        self._checklist_entry = ctk.CTkEntry(add_row, placeholder_text="Add a task...")
        self._checklist_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self._checklist_entry.bind("<Return>", lambda _e: self._add_checklist_item())
        ctk.CTkButton(add_row, text="Add", width=70, command=self._add_checklist_item).pack(side="left")

        self._checklist_frame = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        self._checklist_frame.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.refresh_checklist()

    def _add_checklist_item(self) -> None:
        title = self._checklist_entry.get().strip()
        if not title:
            return
        db_manager.execute("INSERT INTO checklist_items (title) VALUES (?)", (title,))
        self._checklist_entry.delete(0, "end")
        self.refresh_checklist()

    def refresh_checklist(self) -> None:
        for widget in self._checklist_frame.winfo_children():
            widget.destroy()
        rows = db_manager.query("SELECT * FROM checklist_items ORDER BY is_done ASC, id DESC")
        if not rows:
            ctk.CTkLabel(self._checklist_frame, text="No tasks yet.", text_color=("gray40", "gray65")).pack(
                anchor="w"
            )
            return
        for row in rows:
            item = ctk.CTkFrame(self._checklist_frame, fg_color="transparent")
            item.pack(fill="x", pady=2)
            var = ctk.BooleanVar(value=bool(row["is_done"]))
            ctk.CTkCheckBox(
                item, text=row["title"], variable=var,
                command=lambda iid=row["id"], v=var: self._toggle_checklist(iid, v),
            ).pack(side="left", fill="x", expand=True)
            ctk.CTkButton(
                item, text="\u2715", width=26, fg_color="darkred",
                command=lambda iid=row["id"]: self._delete_checklist_item(iid),
            ).pack(side="right")

    def _toggle_checklist(self, item_id: int, var: ctk.BooleanVar) -> None:
        db_manager.execute(
            "UPDATE checklist_items SET is_done = ? WHERE id = ?", (1 if var.get() else 0, item_id)
        )
        self.refresh_checklist()

    def _delete_checklist_item(self, item_id: int) -> None:
        db_manager.execute("DELETE FROM checklist_items WHERE id = ?", (item_id,))
        self.refresh_checklist()

    # ------------------------------------------------------------- Bookmarks

    def _build_bookmarks_tab(self, tab: ctk.CTkFrame) -> None:
        add_row = ctk.CTkFrame(tab, fg_color="transparent")
        add_row.pack(fill="x", padx=12, pady=(12, 6))
        self._bookmark_title_entry = ctk.CTkEntry(add_row, placeholder_text="Title")
        self._bookmark_title_entry.pack(side="left", padx=(0, 8))
        self._bookmark_url_entry = ctk.CTkEntry(add_row, placeholder_text="https://...")
        self._bookmark_url_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkButton(add_row, text="Add", width=70, command=self._add_bookmark).pack(side="left")

        self._bookmarks_frame = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        self._bookmarks_frame.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.refresh_bookmarks()

    def _add_bookmark(self) -> None:
        title = self._bookmark_title_entry.get().strip()
        url = self._bookmark_url_entry.get().strip()
        if not title or not url:
            return
        db_manager.execute("INSERT INTO bookmarks (title, url) VALUES (?, ?)", (title, url))
        self._bookmark_title_entry.delete(0, "end")
        self._bookmark_url_entry.delete(0, "end")
        self.refresh_bookmarks()

    def refresh_bookmarks(self) -> None:
        for widget in self._bookmarks_frame.winfo_children():
            widget.destroy()
        rows = db_manager.query("SELECT * FROM bookmarks ORDER BY id DESC")
        if not rows:
            ctk.CTkLabel(self._bookmarks_frame, text="No bookmarks yet.", text_color=("gray40", "gray65")).pack(
                anchor="w"
            )
            return
        for row in rows:
            item = ctk.CTkFrame(self._bookmarks_frame, fg_color=("gray92", "gray17"), corner_radius=8)
            item.pack(fill="x", pady=2)
            ctk.CTkLabel(item, text=row["title"], font=ctk.CTkFont(weight="bold"), anchor="w").pack(
                side="left", padx=10, pady=6
            )
            ctk.CTkButton(
                item, text="Open", width=60, height=24,
                command=lambda u=row["url"]: webbrowser.open(u),
            ).pack(side="right", padx=(0, 6))
            ctk.CTkButton(
                item, text="Delete", width=60, height=24, fg_color="darkred",
                command=lambda bid=row["id"]: self._delete_bookmark(bid),
            ).pack(side="right", padx=(0, 6))

    def _delete_bookmark(self, bookmark_id: int) -> None:
        db_manager.execute("DELETE FROM bookmarks WHERE id = ?", (bookmark_id,))
        self.refresh_bookmarks()

    # --------------------------------------------------------- Clipboard

    def _build_clipboard_tab(self, tab: ctk.CTkFrame) -> None:
        ctk.CTkLabel(
            tab, text="Automatically records new clipboard content while this tab is open.",
            text_color=("gray40", "gray65"),
        ).pack(anchor="w", padx=12, pady=(12, 6))
        self._clipboard_frame = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        self._clipboard_frame.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.refresh_clipboard()

    def _start_clipboard_polling(self) -> None:
        if self._clipboard_poll_job is not None:
            return
        self._poll_clipboard()

    def _stop_clipboard_polling(self) -> None:
        if self._clipboard_poll_job is not None:
            self.after_cancel(self._clipboard_poll_job)
            self._clipboard_poll_job = None

    def _poll_clipboard(self) -> None:
        try:
            content = self.clipboard_get()
        except Exception:
            content = None

        if content and content != self._last_clipboard_content and content.strip():
            self._last_clipboard_content = content
            db_manager.execute("INSERT INTO clipboard_history (content) VALUES (?)", (content[:2000],))
            self.refresh_clipboard()

        self._clipboard_poll_job = self.after(_CLIPBOARD_POLL_MS, self._poll_clipboard)

    def refresh_clipboard(self) -> None:
        for widget in self._clipboard_frame.winfo_children():
            widget.destroy()
        rows = db_manager.query("SELECT * FROM clipboard_history ORDER BY id DESC LIMIT 30")
        if not rows:
            ctk.CTkLabel(self._clipboard_frame, text="No clipboard history yet.", text_color=("gray40", "gray65")).pack(
                anchor="w"
            )
            return
        for row in rows:
            item = ctk.CTkFrame(self._clipboard_frame, fg_color=("gray92", "gray17"), corner_radius=8)
            item.pack(fill="x", pady=2)
            preview = row["content"][:100].replace("\n", " ")
            ctk.CTkLabel(item, text=preview, anchor="w", wraplength=650, font=ctk.CTkFont(size=11)).pack(
                side="left", fill="x", expand=True, padx=10, pady=6
            )
            ctk.CTkButton(
                item, text="Copy", width=60, height=24,
                command=lambda c=row["content"]: self._copy_to_clipboard(c),
            ).pack(side="right", padx=(0, 6))

    def _copy_to_clipboard(self, content: str) -> None:
        self.clipboard_clear()
        self.clipboard_append(content)
        self._last_clipboard_content = content

    # --------------------------------------------------------- Pomodoro

    def _build_pomodoro_tab(self, tab: ctk.CTkFrame) -> None:
        container = ctk.CTkFrame(tab, fg_color="transparent")
        container.pack(expand=True)

        self._pomodoro_mode_label = ctk.CTkLabel(
            container, text="Focus Session", font=ctk.CTkFont(size=16, weight="bold")
        )
        self._pomodoro_mode_label.pack(pady=(30, 6))

        self._pomodoro_time_label = ctk.CTkLabel(
            container, text=self._format_time(self._pomodoro_remaining), font=ctk.CTkFont(size=48, weight="bold")
        )
        self._pomodoro_time_label.pack(pady=(0, 20))

        button_row = ctk.CTkFrame(container, fg_color="transparent")
        button_row.pack()
        self._pomodoro_start_button = ctk.CTkButton(button_row, text="Start", width=100, command=self._pomodoro_start)
        self._pomodoro_start_button.pack(side="left", padx=6)
        ctk.CTkButton(button_row, text="Pause", width=100, command=self._pomodoro_pause).pack(side="left", padx=6)
        ctk.CTkButton(button_row, text="Reset", width=100, command=self._pomodoro_reset).pack(side="left", padx=6)

    @staticmethod
    def _format_time(seconds: int) -> str:
        minutes, secs = divmod(max(seconds, 0), 60)
        return f"{minutes:02d}:{secs:02d}"

    def _pomodoro_start(self) -> None:
        if self._pomodoro_running:
            return
        self._pomodoro_running = True
        self._pomodoro_tick()

    def _pomodoro_pause(self) -> None:
        self._pomodoro_running = False
        if self._pomodoro_job is not None:
            self.after_cancel(self._pomodoro_job)
            self._pomodoro_job = None

    def _pomodoro_reset(self) -> None:
        self._pomodoro_pause()
        self._pomodoro_on_break = False
        self._pomodoro_remaining = _POMODORO_WORK_SECONDS
        self._pomodoro_mode_label.configure(text="Focus Session")
        self._pomodoro_time_label.configure(text=self._format_time(self._pomodoro_remaining))

    def _pomodoro_tick(self) -> None:
        if not self._pomodoro_running:
            return
        self._pomodoro_remaining -= 1
        if self._pomodoro_remaining <= 0:
            self._pomodoro_on_break = not self._pomodoro_on_break
            self._pomodoro_remaining = (
                _POMODORO_BREAK_SECONDS if self._pomodoro_on_break else _POMODORO_WORK_SECONDS
            )
            self._pomodoro_mode_label.configure(
                text="Break Time" if self._pomodoro_on_break else "Focus Session"
            )
        self._pomodoro_time_label.configure(text=self._format_time(self._pomodoro_remaining))
        self._pomodoro_job = self.after(1000, self._pomodoro_tick)

    # --------------------------------------------------------- Snippets

    def _build_snippets_tab(self, tab: ctk.CTkFrame) -> None:
        top_row = ctk.CTkFrame(tab, fg_color="transparent")
        top_row.pack(fill="x", padx=12, pady=(12, 6))
        ctk.CTkButton(top_row, text="+ New Snippet", command=self._new_snippet_dialog).pack(side="left")

        self._snippets_frame = ctk.CTkScrollableFrame(tab, fg_color="transparent")
        self._snippets_frame.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.refresh_snippets()

    def _new_snippet_dialog(self) -> None:
        dialog = ctk.CTkToplevel(self)
        dialog.title("New Snippet")
        dialog.geometry("400x320")
        dialog.grab_set()

        ctk.CTkLabel(dialog, text="Title", anchor="w").pack(fill="x", padx=20, pady=(20, 2))
        title_entry = ctk.CTkEntry(dialog)
        title_entry.pack(fill="x", padx=20)

        ctk.CTkLabel(dialog, text="Content", anchor="w").pack(fill="x", padx=20, pady=(10, 2))
        content_box = ctk.CTkTextbox(dialog, height=150)
        content_box.pack(fill="both", expand=True, padx=20)

        def save() -> None:
            title = title_entry.get().strip() or "Untitled"
            content = content_box.get("1.0", "end").strip()
            db_manager.execute("INSERT INTO snippets (title, content) VALUES (?, ?)", (title, content))
            dialog.destroy()
            self.refresh_snippets()

        ctk.CTkButton(dialog, text="Save", command=save).pack(fill="x", padx=20, pady=(10, 20))

    def refresh_snippets(self) -> None:
        for widget in self._snippets_frame.winfo_children():
            widget.destroy()
        rows = db_manager.query("SELECT * FROM snippets ORDER BY id DESC")
        if not rows:
            ctk.CTkLabel(self._snippets_frame, text="No snippets yet.", text_color=("gray40", "gray65")).pack(
                anchor="w"
            )
            return
        for row in rows:
            item = ctk.CTkFrame(self._snippets_frame, fg_color=("gray92", "gray17"), corner_radius=8)
            item.pack(fill="x", pady=2)
            ctk.CTkLabel(item, text=row["title"], font=ctk.CTkFont(weight="bold"), anchor="w").pack(
                side="left", padx=10, pady=6
            )
            ctk.CTkButton(
                item, text="Copy", width=60, height=24,
                command=lambda c=row["content"]: self._copy_to_clipboard(c),
            ).pack(side="right", padx=(0, 6))
            ctk.CTkButton(
                item, text="Delete", width=60, height=24, fg_color="darkred",
                command=lambda sid=row["id"]: self._delete_snippet(sid),
            ).pack(side="right", padx=(0, 6))

    def _delete_snippet(self, snippet_id: int) -> None:
        db_manager.execute("DELETE FROM snippets WHERE id = ?", (snippet_id,))
        self.refresh_snippets()
