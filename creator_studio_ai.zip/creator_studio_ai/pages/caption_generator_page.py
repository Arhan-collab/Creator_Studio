"""Caption Generator: platform-specific captions in a chosen tone/length."""

from __future__ import annotations

import customtkinter as ctk

from config.app_config import CAPTION_TONES, SOCIAL_PLATFORMS
from modules.generator_page_base import GeneratorPageBase


class CaptionGeneratorPage(GeneratorPageBase):
    page_key = "caption_generator"
    content_type = "caption"
    page_title = "Caption Generator"
    page_subtitle = "Generate a caption tailored to a specific platform and tone."

    def build_form(self, parent: ctk.CTkFrame) -> None:
        row1 = ctk.CTkFrame(parent, fg_color="transparent")
        row1.pack(fill="x", pady=4)
        ctk.CTkLabel(row1, text="What is this post about", width=170, anchor="w").pack(side="left")
        self._topic_entry = ctk.CTkEntry(row1, placeholder_text="e.g. Behind the scenes of my studio setup")
        self._topic_entry.pack(side="left", fill="x", expand=True)

        row2 = ctk.CTkFrame(parent, fg_color="transparent")
        row2.pack(fill="x", pady=4)
        ctk.CTkLabel(row2, text="Platform", width=170, anchor="w").pack(side="left")
        self._platform_menu = ctk.CTkOptionMenu(row2, values=SOCIAL_PLATFORMS)
        self._platform_menu.pack(side="left")

        row3 = ctk.CTkFrame(parent, fg_color="transparent")
        row3.pack(fill="x", pady=4)
        ctk.CTkLabel(row3, text="Tone / length", width=170, anchor="w").pack(side="left")
        self._tone_menu = ctk.CTkOptionMenu(row3, values=CAPTION_TONES)
        self._tone_menu.pack(side="left")

    def get_topic(self) -> str:
        return self._topic_entry.get().strip()

    def get_platform(self) -> str:
        return self._platform_menu.get()

    def build_prompt(self) -> tuple[str, str]:
        topic = self.get_topic()
        if not topic:
            self.set_status("Describe the post first.")
            return "", ""

        platform = self._platform_menu.get()
        tone = self._tone_menu.get()

        system_prompt = f"You write {tone.lower()} captions optimized for {platform}."
        user_prompt = (
            f"Write a {tone.lower()} caption for a {platform} post about: {topic}. "
            "Include relevant emojis where natural, and end with 3-5 relevant hashtags."
        )
        return system_prompt, user_prompt
